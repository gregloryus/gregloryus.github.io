#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");
const { parseArgs, asNumber, asBoolean } = require("./headless.js");

const FULL_ARMS = Object.freeze([
  { id: "A", name: "exposure-only", exposure: true, shade: false, freqDep: false },
  { id: "B", name: "exposure-plus-frequency", exposure: true, shade: false, freqDep: true },
  { id: "C", name: "shade-only", exposure: false, shade: true, freqDep: false },
  { id: "D", name: "shade-plus-frequency", exposure: false, shade: true, freqDep: true },
  { id: "E", name: "both-energy", exposure: true, shade: true, freqDep: false },
  { id: "F", name: "both-energy-plus-frequency", exposure: true, shade: true, freqDep: true },
]);

function parseSeeds(text) {
  const source = String(text || "1-10");
  const seeds = [];
  for (const part of source.split(",")) {
    const match = part.trim().match(/^(\d+)\s*-\s*(\d+)$/);
    if (match) {
      const start = Number(match[1]);
      const end = Number(match[2]);
      const step = start <= end ? 1 : -1;
      for (let value = start; value !== end + step; value += step) seeds.push(value >>> 0);
    } else if (part.trim()) seeds.push(Number(part.trim()) >>> 0);
  }
  return Array.from(new Set(seeds));
}

function tickLabel(ticks) {
  if (ticks % 1000000 === 0) return `${ticks / 1000000}m`;
  if (ticks % 1000 === 0) return `${ticks / 1000}k`;
  return String(ticks);
}

function runNode(script, args) {
  const result = spawnSync(process.execPath, [script, ...args], {
    encoding: "utf8",
    maxBuffer: 20 * 1024 * 1024,
  });
  if (result.status !== 0) {
    if (result.stdout) process.stderr.write(result.stdout);
    if (result.stderr) process.stderr.write(result.stderr);
    throw new Error(`${path.basename(script)} exited with status ${result.status}`);
  }
  return result.stdout;
}

function flattenSummary(run, summary) {
  const row = {
    arm: run.arm.id,
    armName: run.arm.name,
    seed: run.seed,
    exposure: run.arm.exposure ? 1 : 0,
    shade: run.arm.shade ? 1 : 0,
    frequencyDependence: run.arm.freqDep ? 1 : 0,
    ticks: summary.lastTick,
  };
  for (const setName of ["genomes", "subtrees"]) {
    const prefix = setName === "genomes" ? "genome" : "subtree";
    const set = summary[setName];
    row[`${prefix}FinalLiveTypes`] = set.final.liveTypes;
    row[`${prefix}FinalKnownTypes`] = set.final.knownTypes;
    row[`${prefix}FinalTotalCumulative`] = set.final.totalCumulative;
    row[`${prefix}FinalMedianNormalized`] = set.final.medianNormalized;
    row[`${prefix}FinalNewActivity`] = set.final.newActivity;
    row[`${prefix}CumulativeSlope`] = set.lastHalfSlopePerMillionTicks.totalCumulative;
    row[`${prefix}MedianSlope`] = set.lastHalfSlopePerMillionTicks.medianNormalized;
    row[`${prefix}NewActivitySlope`] = set.lastHalfSlopePerMillionTicks.newActivity;
    row[`${prefix}PositiveNewFraction`] = set.positiveNewActivityFractionLastHalf;
  }
  return row;
}

function mean(values) {
  return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;
}

function aggregateByArm(rows) {
  const numericFields = Object.keys(rows[0] || {}).filter((key) =>
    !["arm", "armName", "seed", "exposure", "shade", "frequencyDependence", "ticks"].includes(key)
  );
  return FULL_ARMS.map((arm) => {
    const matching = rows.filter((row) => row.arm === arm.id);
    if (!matching.length) return null;
    const result = {
      arm: arm.id,
      armName: arm.name,
      exposure: arm.exposure,
      shade: arm.shade,
      frequencyDependence: arm.freqDep,
      runs: matching.length,
    };
    for (const field of numericFields) result[field] = mean(matching.map((row) => row[field]));
    return result;
  }).filter(Boolean);
}

function writeCsv(filePath, rows) {
  if (!rows.length) return;
  const fields = Object.keys(rows[0]);
  const lines = [fields.join(",")];
  for (const row of rows) {
    lines.push(fields.map((field) => String(row[field])).join(","));
  }
  fs.writeFileSync(filePath, lines.join("\n") + "\n", "utf8");
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) {
    process.stdout.write(
      "Usage: node experiment.js [--arms full|reduced] [--seeds 1-10] [--ticks 3000000]\n" +
      "       [--cols 160] [--rows 100] [--telemetry 1000] [--out-dir runs/factorial]\n" +
      "       [--analyze on|off] [--force] [--quick]\n"
    );
    return;
  }
  const quick = asBoolean(args.quick, false);
  const armMode = String(args.arms || (quick ? "reduced" : "full"));
  const arms = armMode === "reduced" ? FULL_ARMS.slice(0, 4) : FULL_ARMS;
  if (!["reduced", "full"].includes(armMode)) throw new Error("--arms must be reduced or full");
  const seeds = parseSeeds(args.seeds || (quick ? "1,2" : "1-10"));
  const ticks = Math.max(1, asNumber(args.ticks, quick ? 100000 : 3000000) | 0);
  const cols = Math.max(3, asNumber(args.cols, quick ? 48 : 160) | 0);
  const rows = Math.max(3, asNumber(args.rows, quick ? 32 : 100) | 0);
  const telemetry = Math.max(1, asNumber(args.telemetry, 1000) | 0);
  const shadowResetTicks = Math.max(0, asNumber(args["shadow-reset-ticks"], 1000) | 0);
  const analyze = asBoolean(args.analyze, true);
  const force = asBoolean(args.force, false);
  const outputDirectory = path.resolve(String(args["out-dir"] || "runs/factorial"));
  const runDirectory = path.join(outputDirectory, "telemetry");
  const analysisDirectory = path.join(outputDirectory, "analysis");
  fs.mkdirSync(runDirectory, { recursive: true });
  if (analyze) fs.mkdirSync(analysisDirectory, { recursive: true });

  const headlessScript = path.join(__dirname, "headless.js");
  const analysisScript = path.join(__dirname, "analyze.js");
  const runs = [];
  for (const arm of arms) {
    for (const seed of seeds) runs.push({ arm, seed });
  }

  for (let i = 0; i < runs.length; i++) {
    const run = runs[i];
    const base = `${run.arm.id}-${run.arm.name}-seed${run.seed}-${tickLabel(ticks)}`;
    const telemetryPath = path.join(runDirectory, `${base}.jsonl`);
    const runAnalysisDirectory = path.join(analysisDirectory, base);
    const summaryPath = path.join(runAnalysisDirectory, "summary.json");
    process.stdout.write(
      `[${i + 1}/${runs.length}] ${run.arm.id} seed ${run.seed}` +
      (fs.existsSync(telemetryPath) && !force ? " · telemetry exists" : " · simulating") + "\n"
    );
    if (!fs.existsSync(telemetryPath) || force) {
      runNode(headlessScript, [
        "--ticks", String(ticks),
        "--cols", String(cols),
        "--rows", String(rows),
        "--seed", String(run.seed),
        "--telemetry", String(telemetry),
        "--output", telemetryPath,
        "--exposure", run.arm.exposure ? "on" : "off",
        "--shade", run.arm.shade ? "on" : "off",
        "--freq-dep", run.arm.freqDep ? "on" : "off",
      ]);
    }
    if (analyze && (!fs.existsSync(summaryPath) || force)) {
      runNode(analysisScript, [
        "--input", telemetryPath,
        "--out-dir", runAnalysisDirectory,
        "--shadow-seed", String((8675309 + run.seed) >>> 0),
        "--shadow-reset-ticks", String(shadowResetTicks),
      ]);
    }
    run.telemetryPath = path.relative(outputDirectory, telemetryPath);
    run.analysisPath = analyze ? path.relative(outputDirectory, runAnalysisDirectory) : null;
  }

  const manifest = {
    format: "tbt-oee-factorial-v1",
    armMode,
    ticks,
    seeds,
    cols,
    rows,
    telemetryInterval: telemetry,
    shadowResetTicks,
    runs: runs.map((run) => ({
      arm: run.arm,
      seed: run.seed,
      telemetry: run.telemetryPath,
      analysis: run.analysisPath,
    })),
  };
  fs.writeFileSync(
    path.join(outputDirectory, "manifest.json"),
    JSON.stringify(manifest, null, 2) + "\n",
    "utf8"
  );

  if (analyze) {
    const rowsOut = runs.map((run) => {
      const base = `${run.arm.id}-${run.arm.name}-seed${run.seed}-${tickLabel(ticks)}`;
      const summary = JSON.parse(
        fs.readFileSync(path.join(analysisDirectory, base, "summary.json"), "utf8")
      );
      return flattenSummary(run, summary);
    });
    const groups = aggregateByArm(rowsOut);
    writeCsv(path.join(outputDirectory, "run-summary.csv"), rowsOut);
    fs.writeFileSync(
      path.join(outputDirectory, "arm-summary.json"),
      JSON.stringify(groups, null, 2) + "\n",
      "utf8"
    );
  }
  process.stdout.write(`Completed ${runs.length} runs in ${outputDirectory}\n`);
}

if (require.main === module) main();

module.exports = { FULL_ARMS, parseSeeds, flattenSummary, aggregateByArm };
