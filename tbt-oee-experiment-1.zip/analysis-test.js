#!/usr/bin/env node
"use strict";

const assert = require("assert");
const { ActivityTracker, ShadowPopulation } = require("./analyze.js");

function shadowOf(entries) {
  const counts = new Map(entries);
  const instances = [];
  for (const [type, count] of entries) {
    for (let i = 0; i < count; i++) instances.push(type);
  }
  return { counts, instances };
}

const tracker = new ActivityTracker();
let record = tracker.score(
  { tick: 0 },
  0,
  { A: 1 },
  shadowOf([["A", 1]]),
  ["A"]
);
assert.strictEqual(record.totalCumulative, 1);
assert.strictEqual(record.totalNormalized, 0);

record = tracker.score(
  { tick: 1000 },
  1,
  { A: 1, B: 1 },
  shadowOf([["A", 1]]),
  ["B"]
);
assert.strictEqual(record.totalCumulative, 3);
assert.strictEqual(record.totalNormalized, 1);
assert.strictEqual(record.medianNormalized, 0.5);
assert.strictEqual(record.newActivity, 0.5);

record = tracker.score(
  { tick: 2000 },
  2,
  { A: 1 },
  shadowOf([["B", 1]]),
  []
);
assert.strictEqual(record.totalCumulative, 3);
assert.strictEqual(record.totalNormalized, 1);
assert.strictEqual(record.newActivity, 0);

record = tracker.score(
  { tick: 3000 },
  3,
  { B: 1 },
  shadowOf([]),
  []
);
assert.strictEqual(record.totalCumulative, 2, "reappearing component lost its activity history");
assert.strictEqual(record.totalNormalized, 1, "normalized history was not restored on reappearance");
assert.strictEqual(record.newActivity, 1);

const shadow = new ShadowPopulation(9);
shadow.reset({ A: 2 });
shadow.applyDemography([
  { op: "birth", genome: "B", subtrees: ["x", "y", "y"] },
  { op: "death", genome: "A", subtrees: ["x", "x"] },
], "genomes");
assert.strictEqual(shadow.instances.length, 2, "whole-genome demography changed shadow size");

const subtreeShadow = new ShadowPopulation(9);
subtreeShadow.reset({ x: 2 });
subtreeShadow.applyDemography([
  { op: "birth", genome: "B", subtrees: ["x", "y", "y"] },
  { op: "death", genome: "A", subtrees: ["x", "x"] },
], "subtrees");
assert.strictEqual(subtreeShadow.instances.length, 3, "subtree demography did not preserve instance turnover");

process.stdout.write(JSON.stringify({ ok: true, finalRecord: record }, null, 2) + "\n");

