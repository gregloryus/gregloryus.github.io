(function () {
  "use strict";

  const canvas = document.getElementById("world");
  const ctx = canvas.getContext("2d", { alpha: false });
  const playButton = document.getElementById("play");
  const stepButton = document.getElementById("step");
  const resetButton = document.getElementById("reset");
  const speedSelect = document.getElementById("speed");
  const seedInput = document.getElementById("seed");
  const exposureInput = document.getElementById("exposure");
  const shadeInput = document.getElementById("shade");
  const freqInput = document.getElementById("freq");
  const status = document.getElementById("status");
  const params = new URLSearchParams(location.search);
  const pixelSize = Math.max(1, Math.min(12, Number(params.get("px")) || 4));

  let sim;
  let running = true;
  let image;
  let frameCounter = 0;

  function boolParam(name, fallback) {
    if (!params.has(name)) return fallback;
    return !["0", "off", "false", "no"].includes(String(params.get(name)).toLowerCase());
  }

  seedInput.value = String(Number(params.get("seed")) || 14);
  exposureInput.checked = boolParam("exposure", true);
  shadeInput.checked = boolParam("shade", false);
  freqInput.checked = boolParam("freq", false);
  if (params.has("speed")) speedSelect.value = params.get("speed");

  function reset() {
    const cols = Math.max(24, Math.floor(innerWidth / pixelSize));
    const rows = Math.max(20, Math.floor(innerHeight / pixelSize));
    canvas.width = cols;
    canvas.height = rows;
    ctx.imageSmoothingEnabled = false;
    image = ctx.createImageData(cols, rows);
    try {
      sim = new TbtOee.TbtSimulation({
        cols,
        rows,
        seed: Number(seedInput.value) || 14,
        energyExposure: exposureInput.checked,
        energyShade: shadeInput.checked,
        frequencyDependence: freqInput.checked,
      });
    } catch (error) {
      status.textContent = error.message;
      return;
    }
    window.sim = sim;
    render(true);
  }

  function setPixel(data, index, color) {
    const offset = index * 4;
    data[offset] = (color >> 16) & 255;
    data[offset + 1] = (color >> 8) & 255;
    data[offset + 2] = color & 255;
    data[offset + 3] = 255;
  }

  function mixColor(a, b, amount) {
    const ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
    const br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
    return (((ar + (br - ar) * amount) | 0) << 16) |
      (((ag + (bg - ag) * amount) | 0) << 8) |
      ((ab + (bb - ab) * amount) | 0);
  }

  function render(forceStatus) {
    const data = image.data;
    const background = 0x07100d;
    for (let i = 0; i < sim.grid.length; i++) setPixel(data, i, background);

    for (let p = 0; p < sim.plants.length; p++) {
      const plant = sim.plants[p];
      const stemColor = mixColor(0x2b8f57, plant.color, 0.5);
      for (let c = 0; c < plant.cells.length; c++) {
        const cell = plant.cells[c];
        let color = stemColor;
        if (cell.isSeed) {
          const ready = Math.min(1, plant.energy / Math.max(1, plant.genome.length));
          color = mixColor(0x754621, plant.reproPhase ? 0xf3e9bc : 0xce633f, ready);
        }
        setPixel(data, cell.y * sim.cols + cell.x, color);
      }
    }

    for (let i = 0; i < sim.travelingSeeds.length; i++) {
      const seed = sim.travelingSeeds[i];
      if (seed.state === 1) setPixel(data, seed.y * sim.cols + seed.x, 0xf2c14e);
    }
    ctx.putImageData(image, 0, 0);

    if (forceStatus || frameCounter % 10 === 0) {
      const s = sim.summary();
      status.textContent = `tick ${s.tick.toLocaleString()} · ${s.population} plants · ${s.cells} cells · ${s.genomeTypes} genomes · mean ${s.meanGenomeLength.toFixed(1)} genes`;
    }
  }

  function loop() {
    if (running && sim) {
      const ticks = Math.max(1, Number(speedSelect.value) | 0);
      sim.tickMany(ticks);
    }
    frameCounter++;
    if (sim) render(false);
    requestAnimationFrame(loop);
  }

  playButton.addEventListener("click", function () {
    running = !running;
    playButton.textContent = running ? "Pause" : "Play";
  });
  stepButton.addEventListener("click", function () {
    if (running) {
      running = false;
      playButton.textContent = "Play";
    }
    sim.tick();
    render(true);
  });
  resetButton.addEventListener("click", reset);
  canvas.addEventListener("click", function () {
    if (!running) {
      sim.tick();
      render(true);
    }
  });
  // Deliberately do not reset on resize: mobile browser chrome produces resize
  // events while scrolling its own bars, which would silently restart evolution.
  // The CSS-scaled low-resolution canvas remains usable until “New world”.

  reset();
  requestAnimationFrame(loop);
})();
