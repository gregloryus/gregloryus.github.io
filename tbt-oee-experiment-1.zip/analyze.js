#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const { XorShift32 } = require("./sim-core.js");
const { parseArgs, asNumber } = require("./headless.js");

function readJsonl(filePath) {
  const lines = fs.readFileSync(filePath, "utf8").split(/\r?\n/).filter(Boolean);
  if (!lines.length) throw new Error("Telemetry file is empty");
  const records = lines.map((line, index) => {
    try {
      return JSON.parse(line);
    } catch (error) {
      throw new Error(`Invalid JSON on line ${index + 1}: ${error.message}`);
    }
  });
  const meta = records.find((record) => record.type === "meta");
  const samples = records.filter((record) => record.type === "sample");
  if (!meta) throw new Error("Telemetry is missing its meta record");
  if (!samples.length) throw new Error("Telemetry contains no samples");
  return { meta, samples };
}

function sumObject(object) {
  let total = 0;
  const values = Object.values(object || {});
  for (let i = 0; i < values.length; i++) total += Number(values[i]) || 0;
  return total;
}

function increment(map, key, amount) {
  const next = (map.get(key) || 0) + amount;
  if (next) map.set(key, next);
  else map.delete(key);
}

function objectToMap(object) {
  return new Map(Object.entries(object || {}).map(([key, value]) => [key, Number(value)]));
}

function mapsEqualObject(map, object) {
  const keys = new Set([...map.keys(), ...Object.keys(object || {})]);
  for (const key of keys) {
    if ((map.get(key) || 0) !== Number((object || {})[key] || 0)) return false;
  }
  return true;
}

function aggregateDemography(events, componentSet, operation) {
  const counts = new Map();
  for (let i = 0; i < events.length; i++) {
    const event = events[i];
    if (event.op !== operation) continue;
    const components = componentSet === "genomes" ? [event.genome] : event.subtrees;
    for (let j = 0; j < components.length; j++) increment(counts, components[j], 1);
  }
  return counts;
}

function validateTelemetry(meta, samples) {
  if (meta.format !== "tbt-oee-jsonl-v1") {
    throw new Error(`Unsupported telemetry format: ${meta.format}`);
  }
  for (let i = 0; i < samples.length; i++) {
    const sample = samples[i];
    const events = sample.events && sample.events.demography;
    if (!Array.isArray(events)) throw new Error(`Sample ${i} lacks ordered demography`);
    const birthCount = events.filter((event) => event.op === "birth").length;
    const deathCount = events.filter((event) => event.op === "death").length;
    if (birthCount !== sample.births || deathCount !== sample.deaths) {
      throw new Error(`Sample ${i} demographic event totals do not reconcile`);
    }
    for (const setName of ["genomes", "subtrees"]) {
      const prefix = setName === "genomes" ? "genome" : "subtree";
      const births = aggregateDemography(events, setName, "birth");
      const deaths = aggregateDemography(events, setName, "death");
      if (!mapsEqualObject(births, sample.events[`${prefix}Births`])) {
        throw new Error(`Sample ${i} ${setName} birth maps do not reconcile`);
      }
      if (!mapsEqualObject(deaths, sample.events[`${prefix}Deaths`])) {
        throw new Error(`Sample ${i} ${setName} death maps do not reconcile`);
      }
      if (i > 0) {
        const expected = objectToMap(samples[i - 1][setName]);
        for (const [key, value] of births) increment(expected, key, value);
        for (const [key, value] of deaths) increment(expected, key, -value);
        if (!mapsEqualObject(expected, sample[setName])) {
          throw new Error(`Sample ${i} ${setName} live counts do not follow its events`);
        }
      }
    }
  }
}

class ShadowPopulation {
  constructor(seed) {
    this.rng = new XorShift32(seed);
    this.instances = [];
    this.counts = new Map();
    this.known = [];
    this.knownSet = new Set();
  }

  learn(components) {
    for (let i = 0; i < components.length; i++) {
      const component = components[i];
      if (!this.knownSet.has(component)) {
        this.knownSet.add(component);
        this.known.push(component);
      }
    }
  }

  addInstance(component) {
    this.instances.push(component);
    increment(this.counts, component, 1);
  }

  addRandomInstances(count) {
    if (count > 0 && !this.known.length) {
      throw new Error("Shadow birth has no known component pool");
    }
    for (let i = 0; i < count; i++) {
      this.addInstance(this.known[this.rng.int(this.known.length)]);
    }
  }

  removeRandomInstances(count) {
    if (count > this.instances.length) {
      throw new Error(`Shadow death requested ${count} of ${this.instances.length} instances`);
    }
    for (let i = 0; i < count; i++) {
      const index = this.rng.int(this.instances.length);
      const component = this.instances[index];
      const last = this.instances.length - 1;
      if (index !== last) this.instances[index] = this.instances[last];
      this.instances.pop();
      increment(this.counts, component, -1);
    }
  }

  reset(realCounts) {
    this.instances.length = 0;
    this.counts.clear();
    const types = Object.keys(realCounts || {});
    this.learn(types);
    for (let i = 0; i < types.length; i++) {
      const count = Number(realCounts[types[i]]) || 0;
      for (let j = 0; j < count; j++) this.addInstance(types[i]);
    }
  }

  applyDemography(events, componentSet) {
    for (let i = 0; i < events.length; i++) {
      const event = events[i];
      const components = componentSet === "genomes" ? [event.genome] : event.subtrees;
      this.learn(components);
      if (event.op === "birth") this.addRandomInstances(components.length);
      else if (event.op === "death") this.removeRandomInstances(components.length);
      else throw new Error(`Unknown demographic operation: ${event.op}`);
    }
  }
}

function median(values) {
  if (!values.length) return 0;
  const sorted = values.slice().sort((a, b) => a - b);
  const middle = sorted.length >> 1;
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

class ActivityTracker {
  constructor() {
    this.realCumulative = new Map();
    this.normalizedCumulative = new Map();
    this.firstSeenSample = new Map();
  }

  learnRealTypes(types, sampleIndex) {
    for (let i = 0; i < types.length; i++) {
      if (!this.firstSeenSample.has(types[i])) {
        this.firstSeenSample.set(types[i], sampleIndex);
      }
    }
  }

  score(sample, sampleIndex, realCounts, shadow, discoveredTypes) {
    const realTypes = Object.keys(realCounts || {});
    this.learnRealTypes(discoveredTypes || realTypes, sampleIndex);
    this.learnRealTypes(realTypes, sampleIndex);
    const allTypes = new Set([
      ...this.firstSeenSample.keys(),
      ...this.realCumulative.keys(),
      ...this.normalizedCumulative.keys(),
      ...realTypes,
      ...shadow.counts.keys(),
    ]);
    const normalized = new Map();
    let totalCumulative = 0;

    for (const type of allTypes) {
      const realPresent = Number(realCounts[type] || 0) > 0;
      const shadowPresent = (shadow.counts.get(type) || 0) > 0;
      const realHistory = (this.realCumulative.get(type) || 0) + (realPresent ? 1 : 0);
      this.realCumulative.set(type, realHistory);
      // Channon's a_i(t) retains accumulated history but is read as zero while
      // the component is absent from the real model.
      const realActivity = realPresent ? realHistory : 0;
      const value = (this.normalizedCumulative.get(type) || 0) +
        (realPresent ? 1 : 0) -
        (shadowPresent ? 1 : 0);
      this.normalizedCumulative.set(type, value);
      normalized.set(type, value);
      totalCumulative += realActivity;
    }

    const liveNormalized = [];
    let totalNormalized = 0;
    let minimumLiveNormalized = 0;
    for (let i = 0; i < realTypes.length; i++) {
      const value = normalized.get(realTypes[i]) || 0;
      liveNormalized.push(value);
      totalNormalized += value;
      if (value < minimumLiveNormalized) minimumLiveNormalized = value;
    }
    // aN_i(t) is read as zero when i is absent from the real model, so the
    // endogenous negative threshold is taken over currently real components.
    const noiseFloor = Math.abs(minimumLiveNormalized);
    let newActivityNumerator = 0;
    let newComponentsAboveNoise = 0;
    for (let i = 0; i < realTypes.length; i++) {
      const type = realTypes[i];
      const value = normalized.get(type) || 0;
      if ((this.firstSeenSample.get(type) || 0) > 0 && value > noiseFloor) {
        newActivityNumerator += value;
        newComponentsAboveNoise++;
      }
    }

    return {
      tick: sample.tick,
      populationInstances: sumObject(realCounts),
      liveTypes: realTypes.length,
      knownTypes: this.firstSeenSample.size,
      totalCumulative,
      totalNormalized,
      medianNormalized: median(liveNormalized),
      newActivity: realTypes.length ? newActivityNumerator / realTypes.length : 0,
      noiseFloor,
      newComponentsAboveNoise,
      shadowInstances: shadow.instances.length,
      shadowLiveTypes: shadow.counts.size,
    };
  }
}

function analyzeComponentSet(samples, componentSet, seed, resetEverySamples) {
  const shadow = new ShadowPopulation(seed);
  const tracker = new ActivityTracker();
  shadow.reset(samples[0][componentSet]);
  const initialDiscovered = componentSet === "genomes"
    ? samples[0].events.demography.flatMap((event) => [event.genome])
    : samples[0].events.demography.flatMap((event) => event.subtrees);
  const records = [
    tracker.score(samples[0], 0, samples[0][componentSet], shadow, initialDiscovered),
  ];

  for (let i = 1; i < samples.length; i++) {
    const sample = samples[i];
    const discovered = componentSet === "genomes"
      ? sample.events.demography.flatMap((event) => event.op === "birth" ? [event.genome] : [])
      : sample.events.demography.flatMap((event) => event.op === "birth" ? event.subtrees : []);
    shadow.applyDemography(sample.events.demography, componentSet);
    const expectedInstances = sumObject(sample[componentSet]);
    if (shadow.instances.length !== expectedInstances) {
      throw new Error(
        `${componentSet} shadow size ${shadow.instances.length} != real ${expectedInstances} at tick ${sample.tick}`
      );
    }
    records.push(tracker.score(sample, i, sample[componentSet], shadow, discovered));
    if (resetEverySamples > 0 && i % resetEverySamples === 0) {
      shadow.reset(sample[componentSet]);
    }
  }
  return records;
}

const CSV_FIELDS = [
  "tick",
  "populationInstances",
  "liveTypes",
  "knownTypes",
  "totalCumulative",
  "totalNormalized",
  "medianNormalized",
  "newActivity",
  "noiseFloor",
  "newComponentsAboveNoise",
  "shadowInstances",
  "shadowLiveTypes",
];

function writeCsv(filePath, records) {
  const lines = [CSV_FIELDS.join(",")];
  for (let i = 0; i < records.length; i++) {
    lines.push(CSV_FIELDS.map((field) => String(records[i][field])).join(","));
  }
  fs.writeFileSync(filePath, lines.join("\n") + "\n", "utf8");
}

function regressionSlope(records, field) {
  if (records.length < 2) return 0;
  const start = Math.floor(records.length / 2);
  let sx = 0, sy = 0, sxx = 0, sxy = 0, n = 0;
  for (let i = start; i < records.length; i++) {
    const x = records[i].tick / 1000000;
    const y = records[i][field];
    sx += x; sy += y; sxx += x * x; sxy += x * y; n++;
  }
  const denominator = n * sxx - sx * sx;
  return denominator ? (n * sxy - sx * sy) / denominator : 0;
}

function summarize(records) {
  const lastHalf = records.slice(Math.floor(records.length / 2));
  return {
    final: records[records.length - 1],
    maxima: {
      totalCumulative: Math.max(...records.map((record) => record.totalCumulative)),
      medianNormalized: Math.max(...records.map((record) => record.medianNormalized)),
      newActivity: Math.max(...records.map((record) => record.newActivity)),
      knownTypes: Math.max(...records.map((record) => record.knownTypes)),
    },
    lastHalfSlopePerMillionTicks: {
      totalCumulative: regressionSlope(records, "totalCumulative"),
      medianNormalized: regressionSlope(records, "medianNormalized"),
      newActivity: regressionSlope(records, "newActivity"),
    },
    positiveNewActivityFractionLastHalf: lastHalf.length
      ? lastHalf.filter((record) => record.newActivity > 0).length / lastHalf.length
      : 0,
  };
}

function formatNumber(value) {
  if (!Number.isFinite(value)) return "—";
  const absolute = Math.abs(value);
  if (absolute >= 1000000) return (value / 1000000).toFixed(1) + "m";
  if (absolute >= 1000) return (value / 1000).toFixed(1) + "k";
  if (absolute >= 10) return value.toFixed(1);
  return value.toFixed(2);
}

function escapeXml(text) {
  return String(text).replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&apos;",
  })[character]);
}

function chartPath(records, field, x, y, width, height, minY, maxY) {
  const maxPoints = 800;
  const stride = Math.max(1, Math.ceil(records.length / maxPoints));
  const firstTick = records[0].tick;
  const lastTick = records[records.length - 1].tick;
  const tickRange = Math.max(1, lastTick - firstTick);
  const valueRange = Math.max(1e-12, maxY - minY);
  const points = [];
  for (let i = 0; i < records.length; i += stride) {
    const px = x + ((records[i].tick - firstTick) / tickRange) * width;
    const py = y + height - ((records[i][field] - minY) / valueRange) * height;
    points.push(`${px.toFixed(2)},${py.toFixed(2)}`);
  }
  const last = records[records.length - 1];
  if ((records.length - 1) % stride !== 0) {
    const px = x + ((last.tick - firstTick) / tickRange) * width;
    const py = y + height - ((last[field] - minY) / valueRange) * height;
    points.push(`${px.toFixed(2)},${py.toFixed(2)}`);
  }
  return points.join(" ");
}

function renderSvg(genomes, subtrees, title) {
  const width = 1200;
  const height = 760;
  const marginX = 56;
  const top = 100;
  const gapX = 34;
  const gapY = 64;
  const panelWidth = (width - marginX * 2 - gapX * 2) / 3;
  const panelHeight = (height - top - 52 - gapY) / 2;
  const specs = [
    ["totalCumulative", "Total cumulative", "#72d6a0"],
    ["medianNormalized", "Median normalized", "#f0ca68"],
    ["newActivity", "New activity", "#ee7f73"],
  ];
  const rows = [["Whole genomes", genomes], ["Full subtrees ≥2", subtrees]];
  const svg = [
    `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">`,
    `<rect width="100%" height="100%" fill="#08110e"/>`,
    `<style>text{font-family:Inter,system-ui,sans-serif;fill:#dce9e1}.muted{fill:#86a496}.axis{stroke:#426052;stroke-width:1}.zero{stroke:#745e58;stroke-dasharray:4 4}.line{fill:none;stroke-width:2}</style>`,
    `<text x="${marginX}" y="36" font-size="22" font-weight="700">${escapeXml(title)}</text>`,
    `<text x="${marginX}" y="58" font-size="12" class="muted">Finite-run diagnostics; persistence is sampled once per telemetry interval.</text>`,
  ];

  for (let row = 0; row < rows.length; row++) {
    const rowY = top + row * (panelHeight + gapY);
    svg.push(`<text x="${marginX}" y="${rowY - 12}" font-size="14" font-weight="700">${rows[row][0]}</text>`);
    for (let column = 0; column < specs.length; column++) {
      const [field, label, color] = specs[column];
      const records = rows[row][1];
      const panelX = marginX + column * (panelWidth + gapX);
      const values = records.map((record) => record[field]);
      let minY = Math.min(...values);
      let maxY = Math.max(...values);
      if (minY === maxY) { minY -= 1; maxY += 1; }
      const padding = (maxY - minY) * 0.06;
      minY -= padding;
      maxY += padding;
      svg.push(`<rect x="${panelX}" y="${rowY}" width="${panelWidth}" height="${panelHeight}" rx="4" fill="#0d1d17" stroke="#29483a"/>`);
      svg.push(`<line class="axis" x1="${panelX}" y1="${rowY + panelHeight}" x2="${panelX + panelWidth}" y2="${rowY + panelHeight}"/>`);
      if (minY < 0 && maxY > 0) {
        const zeroY = rowY + panelHeight - ((0 - minY) / (maxY - minY)) * panelHeight;
        svg.push(`<line class="zero" x1="${panelX}" y1="${zeroY}" x2="${panelX + panelWidth}" y2="${zeroY}"/>`);
      }
      svg.push(`<polyline class="line" stroke="${color}" points="${chartPath(records, field, panelX, rowY, panelWidth, panelHeight, minY, maxY)}"/>`);
      svg.push(`<text x="${panelX}" y="${rowY + panelHeight + 18}" font-size="11">${escapeXml(label)}</text>`);
      svg.push(`<text x="${panelX + panelWidth}" y="${rowY - 5}" text-anchor="end" font-size="10" class="muted">max ${escapeXml(formatNumber(Math.max(...values)))}</text>`);
      svg.push(`<text x="${panelX + panelWidth}" y="${rowY + panelHeight + 18}" text-anchor="end" font-size="10" class="muted">tick ${escapeXml(formatNumber(records[records.length - 1].tick))}</text>`);
    }
  }
  svg.push("</svg>");
  return svg.join("\n");
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help || !args.input) {
    process.stdout.write(
      "Usage: node analyze.js --input run.jsonl [--out-dir analysis/run] " +
      "[--shadow-seed 8675309] [--shadow-reset-ticks 1000] " +
      "[--shadow-reset-samples N]\n"
    );
    if (!args.input && !args.help) process.exitCode = 1;
    return;
  }
  const inputPath = path.resolve(String(args.input));
  const defaultDirectory = path.join(
    path.dirname(inputPath),
    path.basename(inputPath, path.extname(inputPath)) + "-analysis"
  );
  const outputDirectory = path.resolve(String(args["out-dir"] || defaultDirectory));
  const shadowSeed = asNumber(args["shadow-seed"], 8675309) >>> 0;
  const { meta, samples } = readJsonl(inputPath);
  validateTelemetry(meta, samples);
  const shadowResetTicks = Math.max(0, asNumber(args["shadow-reset-ticks"], 1000) | 0);
  const explicitResetSamples = args["shadow-reset-samples"] != null
    ? asNumber(args["shadow-reset-samples"], 1)
    : args["shadow-reset"] != null
      ? asNumber(args["shadow-reset"], 1)
      : null;
  const shadowReset = Math.max(
    0,
    explicitResetSamples == null
      ? shadowResetTicks === 0
        ? 0
        : Math.max(1, Math.round(shadowResetTicks / Math.max(1, meta.telemetryInterval)))
      : explicitResetSamples | 0
  );

  const genomes = analyzeComponentSet(samples, "genomes", shadowSeed ^ 0x9e3779b9, shadowReset);
  const subtrees = analyzeComponentSet(samples, "subtrees", shadowSeed ^ 0x85ebca6b, shadowReset);
  fs.mkdirSync(outputDirectory, { recursive: true });
  writeCsv(path.join(outputDirectory, "genomes-activity.csv"), genomes);
  writeCsv(path.join(outputDirectory, "subtrees-activity.csv"), subtrees);

  const summary = {
    format: "tbt-oee-analysis-v1",
    source: path.basename(inputPath),
    samples: samples.length,
    firstTick: samples[0].tick,
    lastTick: samples[samples.length - 1].tick,
    shadowSeed,
    shadowResetTicks,
    shadowResetSamples: shadowReset,
    activityUnit: "one telemetry sample",
    shadowMethod: "ordered matched component-instance births/deaths; type identity drawn uniformly from all real types discovered so far",
    normalizedRule: "running real-minus-shadow presence sum; read as zero while absent from real; total and median use currently real types only",
    finiteRunCaveat: "Positive slopes are diagnostics, not proof of mathematical unboundedness.",
    genomes: summarize(genomes),
    subtrees: summarize(subtrees),
  };
  fs.writeFileSync(
    path.join(outputDirectory, "summary.json"),
    JSON.stringify(summary, null, 2) + "\n",
    "utf8"
  );
  const title = `TBT activity curves · seed ${meta.config.seed} · ${samples[samples.length - 1].tick.toLocaleString()} ticks`;
  fs.writeFileSync(
    path.join(outputDirectory, "activity-curves.svg"),
    renderSvg(genomes, subtrees, title),
    "utf8"
  );
  process.stdout.write(JSON.stringify({ outputDirectory, summary }, null, 2) + "\n");
}

if (require.main === module) main();

module.exports = {
  readJsonl,
  validateTelemetry,
  ShadowPopulation,
  ActivityTracker,
  analyzeComponentSet,
  renderSvg,
};
