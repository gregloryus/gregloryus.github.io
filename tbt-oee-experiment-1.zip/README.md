# TBT Open-Endedness Experiment v1

An instrumented fork of `simplant-20` built from:

- `triple-bit-trees-oee-2.md`
- `tbt-oee-coding-plan-2.md`
- `tbt-oee-plan-addendum-1.md`

It is an experiment first and a visual simulation second. The same deterministic
core runs in the browser and in Node; Node produces raw JSONL telemetry, and a
separate analyzer computes whole-genome and full-subtree activity curves against
a matched-turnover shadow model.

## Fastest ways to run it

### Browser or phone

Open `tbt-oee-standalone-1.html`. It has no dependencies or network requests.

Controls:

- **Pause / Play**, **Step**, and **New world**
- speeds from 1× through 1000×
- seed input
- independent **exposure**, **shade**, and **frequency-dependence** switches

The baseline is exposure on, shade off, frequency-dependence off. At least one
energy source must remain enabled. Clicking the canvas advances one tick while
paused.

Useful URL parameters are `seed`, `px`, `speed`, `exposure`, `shade`, and `freq`.
For example:

```text
tbt-oee-standalone-1.html?seed=14&px=3&speed=100&exposure=0&shade=1&freq=1
```

### Headless baseline

Requires Node 18 or newer and no packages.

```bash
node headless.js \
  --ticks 1000000 --cols 48 --rows 32 --seed 14 \
  --exposure on --shade off --freq-dep off \
  --telemetry 1000 --output runs/baseline.jsonl
```

Analyze it:

```bash
node analyze.js \
  --input runs/baseline.jsonl \
  --out-dir analysis/baseline
```

This writes:

- `genomes-activity.csv`
- `subtrees-activity.csv`
- `summary.json`
- `activity-curves.svg`

### Factorial experiment

Smoke-test the reduced four-arm experiment:

```bash
node experiment.js --quick --out-dir runs/quick
```

Run the planned six arms × ten shared seeds × three million ticks:

```bash
node experiment.js \
  --arms full --seeds 1-10 --ticks 3000000 \
  --cols 160 --rows 100 --telemetry 1000 \
  --out-dir runs/factorial
```

The runner is resumable: existing telemetry and analysis files are skipped.
Pass `--force` to replace them. It writes a manifest, every raw run, every
per-run analysis, `run-summary.csv`, and an arm-level JSON summary.

## Implemented biological and genetic core

- **TBT encoding:** canonical DFS-preorder genomes; three relative slots ordered
  LEFT → UP → RIGHT; a child turns with its attachment slot. Binary text follows
  the reference document literally: `100` is left, `010` forward, `001` right.
- **Development:** local incremental growth with inter-plant clearance. Target
  collisions permanently close that developmental slot, so environment can
  alter the realized body without altering its genotype.
- **Live economy:** cells earn energy, growth spends it, seed construction spends
  it, and plants die from starvation or age. There is no external fitness score.
- **Mutation:** 60% symmetric bit flip, 20% portable full-subtree duplication,
  20% full-subtree deletion. Clearing a loaded bit amputates its entire subtree;
  the Simplant v20 no-op ratchet is gone.
- **Exposure energy:** the Simplant rule—three or more empty orthogonal sides by
  default, with the inherited graduated option retained in the core.
- **Shade energy:** a second independent channel. A cell earns only when it is
  the highest occupied cell in its column. A column cache makes eligibility
  O(1); exposure and shade use independent cooldowns and random draws.
- **Frequency dependence:** exact-genome roots within the configured radius
  reduce germination by
  `min(1, K × similarCount / freqDepMaxNeighbors)`. Defaults are radius 12,
  `K=1`, and saturation at four similar neighbors. This denominator is explicit
  and configurable because the plan left `maxNeighbors` undefined.
- **Boundaries:** horizontal wrapping is retained. Vertical wrapping is removed
  everywhere. Growth is blocked at sky/bottom boundaries, energy sees empty sky,
  and airborne seeds reflect vertically rather than teleporting.
- **Randomness:** one xorshift32 stream; no `Math.random()` in the core.

## Instrumentation and shadow model

Each telemetry sample contains live multiplicities for:

- whole canonical genomes
- every full canonical subtree of size at least two, retaining multiplicity

It also contains exact ordered plant birth/death events plus independently
auditable component birth/death maps. This matters because net snapshots cannot
recover turnover that cancels within one sampling interval.

The analyzer first rejects any run whose current counts do not reconcile with
its event stream. It then runs one shadow per component set:

- real component-instance births and deaths occur in their original order
- each shadow birth adds the same number of component instances as the real birth
- each shadow death removes the same number of random shadow instances
- newborn shadow identities are drawn uniformly from all real component types
  discovered so far
- the shadow resets at a 1,000-simulation-tick boundary by default—once per
  sample when telemetry is sampled every 1,000 ticks

Thus genome-length evolution cannot give the subtree shadow a different-sized
component economy. Activity increments once per telemetry sample; the sampling
interval should therefore remain identical across arms.

The analyzer outputs total cumulative activity, total and median normalized
activity, the endogenous negative noise floor, and new activity. Its reported
slopes are finite-run diagnostics. They are not, by themselves, proof that any
quantity is mathematically unbounded.

## Included baseline

`runs/baseline-seed14-1m.jsonl` is the exposure-only, frequency-off baseline on a
48×32 grid. It completed one million ticks with deterministic digest `f45007b9`
in the original telemetry run. The final, strengthened state digest for the same
dynamics is `7420f04d`. The corresponding analysis is under
`analysis/baseline-seed14-1m/`.

This baseline is a useful near-miss, not a pass. Whole-genome new activity is
small but positive through most of the latter half; full-subtree new activity is
zero throughout the latter half, its final total normalized activity is negative,
and its normalized median is flat. In other words, new body plans still appear,
but this run does not show sustained *adaptive compositional* novelty. The planned
replicate factorial experiment tests whether shade or frequency dependence changes
that result.

## Files

- `sim-core.js` — renderer-free deterministic ecology and genetics
- `browser.html` + `browser-view.js` — modular browser view
- `tbt-oee-standalone-1.html` — generated single-file browser build
- `headless.js` — Node runner and JSONL writer
- `analyze.js` — telemetry auditor, shadow model, CSV/SVG analysis
- `experiment.js` — resumable reduced/full factorial orchestration
- `core-test.js` — encoding, boundary, mutation, cache, frequency, and parity tests
- `analysis-test.js` — normalized-history and matched-turnover regression tests
- `make-standalone.js` — rebuilds the single-file browser version

Run all deterministic unit/regression checks with:

```bash
npm test
```

## Deliberately absent

Soil, water, nutrients, litter, pollen, seasons, terrain, organs, herbivores,
decomposers, barriers, geography, and any aesthetic fitness bonus. Those are held
back until the measured baseline and factorial experiment say what is actually
missing.
