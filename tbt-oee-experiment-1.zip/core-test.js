#!/usr/bin/env node
"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const core = require("./sim-core.js");

function developmentalPositions(api) {
  const sim = new api.TbtSimulation({
    cols: 20,
    rows: 20,
    initialSeeds: 0,
    energyExposure: false,
    energyShade: true,
    absorbProbability: 0,
    starvationTicks: 10000,
  });
  // North-facing root: UP, then RIGHT, then UP in the child's east-facing frame.
  const plant = sim.createPlant(new Uint8Array([0b010, 0b001, 0b010, 0b000]), 10, 10, 10);
  plant.tryGrowOneStep();
  plant.tryGrowOneStep();
  plant.tryGrowOneStep();
  return plant.cells.map((cell) => [cell.x, cell.y, cell.facing]);
}

assert.deepStrictEqual(developmentalPositions(core), [
  [10, 10, 0],
  [10, 9, 0],
  [11, 9, 1],
  [12, 9, 1],
]);

const boundarySim = new core.TbtSimulation({
  cols: 20,
  rows: 20,
  initialSeeds: 0,
  energyExposure: false,
  energyShade: true,
  absorbProbability: 0,
});
const boundaryPlant = boundarySim.createPlant(new Uint8Array([0b010, 0]), 10, 0, 5);
boundaryPlant.tryGrowOneStep();
assert.strictEqual(boundaryPlant.cells.length, 1, "north growth at row 0 must not wrap to the bottom");

assert.throws(
  () => new core.TbtSimulation({ energyExposure: false, energyShade: false }),
  /enable exposure, shade, or both/,
  "a world with no energy source must fail loudly"
);

const shadeSim = new core.TbtSimulation({
  cols: 20,
  rows: 20,
  initialSeeds: 0,
  energyExposure: false,
  energyShade: true,
  absorbProbability: 1,
  energyCooldown: 0,
});
const lowPlant = shadeSim.createPlant(new Uint8Array([0b010, 0]), 10, 10, 5);
lowPlant.tryGrowOneStep();
const lowStem = lowPlant.cells[1];
const lowBefore = lowPlant.energy;
shadeSim.advanceEnergy();
assert.strictEqual(lowPlant.energy, lowBefore + 1, "topmost stem did not earn shade energy");
const highPlant = shadeSim.createPlant(new Uint8Array([0b010, 0]), 10, 7, 5);
highPlant.tryGrowOneStep();
const shadedBefore = lowPlant.energy;
const highBefore = highPlant.energy;
shadeSim.advanceEnergy();
assert.strictEqual(lowPlant.energy, shadedBefore, "a covered stem incorrectly earned shade energy");
assert.strictEqual(highPlant.energy, highBefore + 1, "the new column-top stem did not earn");
shadeSim.removePlantAt(shadeSim.plants.indexOf(highPlant));
assert.strictEqual(shadeSim.columnTopY[lowStem.x], lowStem.y, "column-top cache did not recover after removal");

const frequencySim = new core.TbtSimulation({
  cols: 20,
  rows: 20,
  initialSeeds: 0,
  frequencyDependence: true,
  freqDepRadius: 3,
  freqDepK: 1,
  freqDepMaxNeighbors: 1,
});
const commonGenome = new Uint8Array([0b010, 0]);
const indexedPlant = frequencySim.createPlant(commonGenome, 0, 10, 0);
assert.strictEqual(
  frequencySim.frequencyFailureProbability(commonGenome, 19, 10),
  1,
  "frequency radius did not respect horizontal wrapping"
);
assert.strictEqual(
  frequencySim.frequencyFailureProbability(new Uint8Array([0]), 19, 10),
  0,
  "frequency dependence matched a different genome"
);
frequencySim.removePlantAt(frequencySim.plants.indexOf(indexedPlant));
assert.strictEqual(
  frequencySim.frequencyFailureProbability(commonGenome, 19, 10),
  0,
  "dead roots remained in the genome-position index"
);

// A loaded LEFT branch must be amputated, not treated as a no-op. This is the
// exact Simplant v20 ratchet regression described by the addendum.
const scripted = {
  values: [0, 0, 0],
  int(n) { return Math.min(n - 1, this.values.shift() || 0); },
};
const amputated = core.mutateBitFlip(
  new Uint8Array([0b111, 0b010, 0b000, 0b000, 0b000]),
  scripted,
  { forceSeedStalk: false }
).genome;
assert.deepStrictEqual(Array.from(amputated), [0b011, 0b000, 0b000]);

const mutationRng = new core.XorShift32(77123);
let evolvingGenome = new Uint8Array([0b010, 0b010, 0b010, 0]);
let increases = 0;
let decreases = 0;
const mutationConfig = Object.assign({}, core.DEFAULT_CONFIG);
for (let i = 0; i < 2000; i++) {
  const before = evolvingGenome.length;
  evolvingGenome = core.mutateGenome(evolvingGenome, mutationRng, mutationConfig);
  if (evolvingGenome.length > before) increases++;
  if (evolvingGenome.length < before) decreases++;
}
assert.ok(increases > 0, "mutation never added structure");
assert.ok(decreases > 0, "mutation never removed structure");

const deterministicConfig = { cols: 48, rows: 32, seed: 90210 };
const first = new core.TbtSimulation(deterministicConfig).tickMany(5000);
const second = new core.TbtSimulation(deterministicConfig).tickMany(5000);
assert.strictEqual(first.stateDigest(), second.stateDigest(), "same seed must reproduce exactly");

const source = fs.readFileSync(path.join(__dirname, "sim-core.js"), "utf8");
const browserContext = { console };
vm.createContext(browserContext);
vm.runInContext(source, browserContext, { filename: "sim-core.js" });
assert.ok(browserContext.TbtOee, "browser global export was not created");
const browserRun = new browserContext.TbtOee.TbtSimulation(deterministicConfig).tickMany(5000);
assert.strictEqual(first.stateDigest(), browserRun.stateDigest(), "Node and browser exports diverged");

const telemetrySim = new core.TbtSimulation({ cols: 30, rows: 20, seed: 4 });
const initialSample = telemetrySim.telemetrySnapshot(true);
assert.strictEqual(initialSample.pop, 1);
assert.strictEqual(Object.values(initialSample.genomes).reduce((a, b) => a + b, 0), 1);
assert.strictEqual(Object.values(initialSample.subtrees).reduce((a, b) => a + b, 0), 3);
telemetrySim.tickMany(1000);
const laterSample = telemetrySim.telemetrySnapshot(true);
assert.strictEqual(
  laterSample.events.demography.filter((event) => event.op === "birth").length,
  laterSample.births,
  "ordered birth stream does not match birth count"
);
assert.strictEqual(
  laterSample.events.demography.filter((event) => event.op === "death").length,
  laterSample.deaths,
  "ordered death stream does not match death count"
);
assert.strictEqual(
  Object.values(laterSample.events.genomeBirths).reduce((a, b) => a + b, 0),
  laterSample.births,
  "genome birth events do not match plant births"
);
assert.strictEqual(
  Object.values(laterSample.events.genomeDeaths).reduce((a, b) => a + b, 0),
  laterSample.deaths,
  "genome death events do not match plant deaths"
);

process.stdout.write(JSON.stringify({
  ok: true,
  digest: first.stateDigest(),
  mutationLengthMoves: { increases, decreases, finalLength: evolvingGenome.length },
  summary: first.summary(),
}, null, 2) + "\n");
