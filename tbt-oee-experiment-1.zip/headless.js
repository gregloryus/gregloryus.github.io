#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const { TbtSimulation } = require("./sim-core.js");

function parseArgs(argv) {
  const result = {};
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (!arg.startsWith("--")) continue;
    const equals = arg.indexOf("=");
    if (equals >= 0) {
      result[arg.slice(2, equals)] = arg.slice(equals + 1);
    } else {
      const key = arg.slice(2);
      const next = argv[i + 1];
      if (next != null && !next.startsWith("--")) {
        result[key] = next;
        i++;
      } else result[key] = true;
    }
  }
  return result;
}

function asNumber(value, fallback) {
  if (value == null) return fallback;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function asBoolean(value, fallback) {
  if (value == null) return fallback;
  if (value === true) return true;
  const text = String(value).toLowerCase();
  if (["1", "true", "on", "yes"].includes(text)) return true;
  if (["0", "false", "off", "no"].includes(text)) return false;
  return fallback;
}

function configFromArgs(args) {
  return {
    seed: asNumber(args.seed, 14),
    cols: asNumber(args.cols, 160),
    rows: asNumber(args.rows, 100),
    initialSeeds: asNumber(args["initial-seeds"], 1),
    energyExposure: asBoolean(args.exposure, true),
    energyShade: asBoolean(args.shade, false),
    frequencyDependence: asBoolean(args["freq-dep"], false),
    mutationRate: asNumber(args["mutation-rate"], 0.2),
    absorbProbability: asNumber(args["absorb-probability"], 0.6),
    maxPlantAge: asNumber(args["max-age"], 1000),
    starvationTicks: asNumber(args.starvation, 200),
    airborneSteps: asNumber(args["airborne-steps"], 40),
    germinationClearRadius: asNumber(args["clear-radius"], 3),
    freqDepRadius: asNumber(args["freq-dep-radius"], 12),
    freqDepK: asNumber(args["freq-dep-k"], 1),
    freqDepMaxNeighbors: asNumber(args["freq-dep-max-neighbors"], 4),
  };
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) {
    process.stdout.write(
      "Usage: node headless.js [--ticks 100000] [--seed 14] [--cols 160] [--rows 100]\n" +
      "       [--exposure on|off] [--shade on|off] [--freq-dep on|off]\n" +
      "       [--telemetry 1000] [--output run.jsonl]\n"
    );
    return;
  }
  const ticks = Math.max(0, asNumber(args.ticks, 100000) | 0);
  const sim = new TbtSimulation(configFromArgs(args));
  const started = process.hrtime.bigint();
  let outputPath = null;
  if (args.output) {
    outputPath = path.resolve(String(args.output));
    const telemetryInterval = Math.max(1, asNumber(args.telemetry, 1000) | 0);
    const serializableConfig = Object.assign({}, sim.config, {
      initialGenome: Array.from(sim.config.initialGenome),
    });
    const lines = [JSON.stringify({
      type: "meta",
      format: "tbt-oee-jsonl-v1",
      config: serializableConfig,
      telemetryInterval,
      componentSets: {
        genomes: "whole canonical DFS genomes",
        subtrees: "full canonical DFS subtrees of size >= 2; multiplicity retained",
      },
      boundaries: { horizontal: "wrap", vertical: "reflect/block; no wrap" },
    })];
    lines.push(JSON.stringify(sim.telemetrySnapshot(true)));
    while (sim.tickCount < ticks) {
      const batch = Math.min(telemetryInterval, ticks - sim.tickCount);
      sim.tickMany(batch);
      lines.push(JSON.stringify(sim.telemetrySnapshot(true)));
    }
    fs.mkdirSync(path.dirname(outputPath), { recursive: true });
    fs.writeFileSync(outputPath, lines.join("\n") + "\n", "utf8");
  } else {
    sim.tickMany(ticks);
  }
  const elapsedSeconds = Number(process.hrtime.bigint() - started) / 1e9;
  const result = Object.assign(sim.summary(), {
    digest: sim.stateDigest(),
    elapsedSeconds,
    ticksPerSecond: elapsedSeconds > 0 ? ticks / elapsedSeconds : null,
    verticalWrap: false,
    horizontalWrap: true,
    telemetryFile: outputPath,
  });
  process.stdout.write(JSON.stringify(result, null, 2) + "\n");
}

if (require.main === module) main();

module.exports = { parseArgs, asNumber, asBoolean, configFromArgs };
