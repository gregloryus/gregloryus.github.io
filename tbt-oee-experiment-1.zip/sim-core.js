// TBT OEE experiment core v1
// Renderer-free, deterministic, and usable unchanged in Node or a browser.
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.TbtOee = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  const SLOT_LEFT = 0;
  const SLOT_UP = 1;
  const SLOT_RIGHT = 2;
  // Binary text is LEFT–UP–RIGHT, so LEFT is the high bit and RIGHT the low.
  const SLOT_MASKS = new Uint8Array([0b100, 0b010, 0b001]);

  // Facing order: north, east, south, west. Slots: left, up, right.
  const DIR_DX = new Int8Array([
    -1, 0, 1,
     0, 1, 0,
     1, 0, -1,
     0, -1, 0,
  ]);
  const DIR_DY = new Int8Array([
     0, -1, 0,
    -1,  0, 1,
     0,  1, 0,
     1,  0, -1,
  ]);
  const ROTATIONS = new Uint8Array([
    3, 0, 1,
    0, 1, 2,
    1, 2, 3,
    2, 3, 0,
  ]);

  const DEFAULT_GENOME = new Uint8Array([0b010, 0b010, 0b010, 0b000]);

  const DEFAULT_CONFIG = Object.freeze({
    cols: 160,
    rows: 100,
    seed: 14,
    initialSeeds: 1,
    initialGenome: DEFAULT_GENOME,
    forceSeedStalk: true,
    randomFacing: false,
    airborneSteps: 40,
    mutationRate: 0.2,
    mutationBitFlipWeight: 0.6,
    mutationDuplicationWeight: 0.2,
    mutationDeletionWeight: 0.2,
    maxPlantAge: 1000,
    starvationTicks: 200,
    germinationClearRadius: 3,
    energyExposure: true,
    energyShade: false,
    graduatedAbsorption: false,
    absorbProbability: 0.6,
    energyCooldown: 30,
    childStartingEnergy: false,
    distanceBonus: false,
    distanceBonusFactor: 0.1,
    frequencyDependence: false,
    freqDepRadius: 12,
    freqDepK: 1,
    freqDepMaxNeighbors: 4,
  });

  function normalizeConfig(overrides) {
    const cfg = Object.assign({}, DEFAULT_CONFIG, overrides || {});
    cfg.cols = Math.max(3, cfg.cols | 0);
    cfg.rows = Math.max(3, cfg.rows | 0);
    cfg.seed = Number.isFinite(Number(cfg.seed)) ? Number(cfg.seed) >>> 0 : 14;
    cfg.initialSeeds = Math.max(0, cfg.initialSeeds | 0);
    cfg.airborneSteps = Math.max(0, cfg.airborneSteps | 0);
    cfg.maxPlantAge = Math.max(1, Number(cfg.maxPlantAge));
    cfg.starvationTicks = Math.max(1, cfg.starvationTicks | 0);
    cfg.germinationClearRadius = Math.max(0, cfg.germinationClearRadius | 0);
    cfg.freqDepRadius = Math.max(0, Number(cfg.freqDepRadius));
    cfg.freqDepK = Math.max(0, Number(cfg.freqDepK));
    cfg.freqDepMaxNeighbors = Math.max(1, Number(cfg.freqDepMaxNeighbors));
    cfg.absorbProbability = Math.max(0, Math.min(1, Number(cfg.absorbProbability)));
    cfg.energyCooldown = Math.max(0, cfg.energyCooldown | 0);
    cfg.mutationRate = Math.max(0, Math.min(1, Number(cfg.mutationRate)));
    cfg.mutationBitFlipWeight = Math.max(0, Number(cfg.mutationBitFlipWeight));
    cfg.mutationDuplicationWeight = Math.max(0, Number(cfg.mutationDuplicationWeight));
    cfg.mutationDeletionWeight = Math.max(0, Number(cfg.mutationDeletionWeight));
    if (
      cfg.mutationBitFlipWeight +
        cfg.mutationDuplicationWeight +
        cfg.mutationDeletionWeight <=
      0
    ) {
      throw new Error("At least one mutation operator must have positive weight");
    }
    if (!cfg.energyExposure && !cfg.energyShade) {
      throw new Error("Invalid energy configuration: enable exposure, shade, or both");
    }
    cfg.initialGenome = canonicalGenome(cfg.initialGenome || DEFAULT_GENOME);
    return cfg;
  }

  class XorShift32 {
    constructor(seed) {
      this.state = (seed >>> 0) || 0x6d2b79f5;
    }
    nextUint() {
      let x = this.state >>> 0;
      x ^= x << 13;
      x ^= x >>> 17;
      x ^= x << 5;
      this.state = x >>> 0;
      return this.state;
    }
    float() {
      return this.nextUint() / 0x100000000;
    }
    int(n) {
      if (!(n > 0)) throw new RangeError("PRNG.int requires n > 0");
      return (this.float() * n) | 0;
    }
  }

  class GeneNode {
    constructor(geneBits) {
      this.geneBits = geneBits & 7;
      this.parent = null;
      this.slotFromParent = -1;
      this.children = [null, null, null];
      // Developmental state. Each plant owns its decoded tree.
      this.cell = null;
      this.grownMask = 0;
    }
  }

  function toGenomeArray(genome) {
    if (genome instanceof Uint8Array) return genome;
    if (Array.isArray(genome) || ArrayBuffer.isView(genome)) {
      return Uint8Array.from(genome, (value) => Number(value) & 7);
    }
    throw new TypeError("Genome must be an array-like sequence of 0–7 genes");
  }

  function decodeGenomeToTree(genomeInput) {
    const genome = toGenomeArray(genomeInput);
    let index = 0;
    function build(parent, slotFromParent) {
      if (index >= genome.length) return null;
      const node = new GeneNode(genome[index++]);
      node.parent = parent || null;
      node.slotFromParent = slotFromParent == null ? -1 : slotFromParent;
      for (let slot = 0; slot < 3; slot++) {
        if (node.geneBits & SLOT_MASKS[slot]) {
          const child = build(node, slot);
          if (child) node.children[slot] = child;
          else node.geneBits &= ~SLOT_MASKS[slot];
        }
      }
      return node;
    }
    return build(null, -1) || new GeneNode(0);
  }

  function encodeTreeToGenome(rootNode) {
    const genes = [];
    function visit(node) {
      if (!node) return;
      let bits = 0;
      for (let slot = 0; slot < 3; slot++) {
        if (node.children[slot]) bits |= SLOT_MASKS[slot];
      }
      node.geneBits = bits;
      genes.push(bits);
      for (let slot = 0; slot < 3; slot++) visit(node.children[slot]);
    }
    visit(rootNode);
    return new Uint8Array(genes.length ? genes : [0]);
  }

  function canonicalGenome(genome) {
    return encodeTreeToGenome(decodeGenomeToTree(genome));
  }

  function collectNodesPreorder(rootNode) {
    const nodes = [];
    (function visit(node) {
      if (!node) return;
      nodes.push(node);
      for (let slot = 0; slot < 3; slot++) visit(node.children[slot]);
    })(rootNode);
    return nodes;
  }

  function genomeHash(genomeInput) {
    return Array.prototype.join.call(toGenomeArray(genomeInput), ".");
  }

  function subtreeHashes(genomeInput, includeTerminals) {
    const genome = canonicalGenome(genomeInput);
    const spans = [];
    function scan(start) {
      if (start >= genome.length) return start;
      const bits = genome[start];
      let end = start + 1;
      for (let slot = 0; slot < 3; slot++) {
        if (bits & SLOT_MASKS[slot]) end = scan(end);
      }
      spans.push([start, end]);
      return end;
    }
    scan(0);
    const hashes = [];
    for (let i = 0; i < spans.length; i++) {
      const start = spans[i][0];
      const end = spans[i][1];
      if (includeTerminals || end - start >= 2) {
        hashes.push(Array.prototype.join.call(genome.subarray(start, end), "."));
      }
    }
    return hashes;
  }

  function incrementMap(map, key, amount) {
    const next = (map.get(key) || 0) + amount;
    if (next) map.set(key, next);
    else map.delete(key);
  }

  function mapToSortedObject(map) {
    const object = Object.create(null);
    const keys = Array.from(map.keys()).sort();
    for (let i = 0; i < keys.length; i++) object[keys[i]] = map.get(keys[i]);
    return object;
  }

  function biasedNodeIndex(length, rng, forbidRoot) {
    if (length <= 1) return 0;
    let index = Math.max(rng.int(length), rng.int(length));
    if (forbidRoot && index === 0) index = 1 + rng.int(length - 1);
    return index;
  }

  function cloneSubtree(source, parent, slotFromParent) {
    const clone = new GeneNode(source.geneBits);
    clone.parent = parent || null;
    clone.slotFromParent = slotFromParent == null ? -1 : slotFromParent;
    for (let slot = 0; slot < 3; slot++) {
      if (source.children[slot]) {
        clone.children[slot] = cloneSubtree(source.children[slot], clone, slot);
      }
    }
    return clone;
  }

  function mutationResult(root, operator, changed) {
    return { genome: encodeTreeToGenome(root), operator, changed };
  }

  function mutateBitFlip(genomeInput, rng, config) {
    const cfg = config || DEFAULT_CONFIG;
    const root = decodeGenomeToTree(genomeInput);
    const nodes = collectNodesPreorder(root);
    const geneIndex = biasedNodeIndex(nodes.length, rng, cfg.forceSeedStalk);
    const target = nodes[geneIndex];
    const slot = rng.int(3);
    const child = target.children[slot];
    if (child) target.children[slot] = null;
    else {
      const terminal = new GeneNode(0);
      terminal.parent = target;
      terminal.slotFromParent = slot;
      target.children[slot] = terminal;
    }
    return mutationResult(root, "bitFlip", true);
  }

  function mutateSubtreeDuplication(genomeInput, rng) {
    const root = decodeGenomeToTree(genomeInput);
    const nodes = collectNodesPreorder(root);
    const emptySlots = [];
    for (let i = 0; i < nodes.length; i++) {
      for (let slot = 0; slot < 3; slot++) {
        if (!nodes[i].children[slot]) emptySlots.push([nodes[i], slot]);
      }
    }
    if (!emptySlots.length) return mutationResult(root, "duplication", false);
    const source = nodes[rng.int(nodes.length)];
    const destination = emptySlots[rng.int(emptySlots.length)];
    destination[0].children[destination[1]] = cloneSubtree(
      source,
      destination[0],
      destination[1]
    );
    return mutationResult(root, "duplication", true);
  }

  function mutateSubtreeDeletion(genomeInput, rng) {
    const root = decodeGenomeToTree(genomeInput);
    const nodes = collectNodesPreorder(root);
    if (nodes.length <= 1) return mutationResult(root, "deletion", false);
    // Uniform source/target choice makes duplication and deletion symmetric in
    // expected subtree size. The newer-node bias remains only on bit flips.
    const index = 1 + rng.int(nodes.length - 1);
    const target = nodes[index];
    target.parent.children[target.slotFromParent] = null;
    return mutationResult(root, "deletion", true);
  }

  function mutateGenomeDetailed(genomeInput, rng, config) {
    const cfg = config || DEFAULT_CONFIG;
    const bitWeight = Math.max(0, Number(cfg.mutationBitFlipWeight));
    const duplicationWeight = Math.max(0, Number(cfg.mutationDuplicationWeight));
    const deletionWeight = Math.max(0, Number(cfg.mutationDeletionWeight));
    const total = bitWeight + duplicationWeight + deletionWeight;
    if (!(total > 0)) throw new Error("At least one mutation operator must have positive weight");
    const roll = rng.float() * total;
    if (roll < bitWeight) return mutateBitFlip(genomeInput, rng, cfg);
    if (roll < bitWeight + duplicationWeight) {
      return mutateSubtreeDuplication(genomeInput, rng);
    }
    return mutateSubtreeDeletion(genomeInput, rng);
  }

  function mutateGenome(genomeInput, rng, config) {
    return mutateGenomeDetailed(genomeInput, rng, config).genome;
  }

  function hsvToRgbInt(h, s, v) {
    const scaled = h * 6;
    const sector = scaled | 0;
    const f = scaled - sector;
    const p = v * (1 - s);
    const q = v * (1 - f * s);
    const t = v * (1 - (1 - f) * s);
    let r = v, g = t, b = p;
    switch (sector % 6) {
      case 1: r = q; g = v; b = p; break;
      case 2: r = p; g = v; b = t; break;
      case 3: r = p; g = q; b = v; break;
      case 4: r = t; g = p; b = v; break;
      case 5: r = v; g = p; b = q; break;
    }
    return (((r * 255 + 0.5) | 0) << 16) |
      (((g * 255 + 0.5) | 0) << 8) |
      ((b * 255 + 0.5) | 0);
  }

  function plantColorFromGenome(genome) {
    let sum = 0;
    for (let i = 0; i < genome.length; i++) sum += genome[i] + (i % 7);
    return hsvToRgbInt((sum * 0.01) % 1, 0.78, 0.96);
  }

  class Plant {
    constructor(sim, genomeInput, startingEnergy) {
      this.sim = sim;
      this.id = sim.nextPlantId++;
      this.genome = canonicalGenome(genomeInput);
      this.hash = genomeHash(this.genome);
      this.subtreeComponents = sim.subtreeComponentsForGenome(this.genome);
      this.color = plantColorFromGenome(this.genome);
      this.rootNode = decodeGenomeToTree(this.genome);
      this.seed = null;
      this.energy = Number(startingEnergy) || 0;
      this.freeSproutUsed = false;
      this.cells = [];
      this.frontier = [];
      this.reproPhase = 0;
      this.childGenome = null;
      this.childGeneCount = 0;
      this.age = 0;
      this.ticksWithoutEnergy = 0;
      this.dead = false;
    }

    registerCell(cell) {
      this.cells.push(cell);
      if (!cell.node) return;
      cell.node.cell = cell;
      for (let slot = 0; slot < 3; slot++) {
        if (cell.node.children[slot] && !(cell.node.grownMask & (1 << slot))) {
          this.frontier.push({ node: cell.node, slot });
        }
      }
    }

    removeFrontierAt(index) {
      const last = this.frontier.length - 1;
      if (index !== last) this.frontier[index] = this.frontier[last];
      this.frontier.pop();
    }

    tryGrowOneStep() {
      if (this.energy < 1 && this.freeSproutUsed) return false;
      for (let i = this.frontier.length - 1; i >= 0; i--) {
        if (this.energy < 1 && this.freeSproutUsed) return false;
        const entry = this.frontier[i];
        const node = entry.node;
        const slot = entry.slot;
        const parentCell = node.cell;
        if (!parentCell || !node.children[slot]) {
          this.removeFrontierAt(i);
          continue;
        }
        const directionIndex = parentCell.facing * 3 + slot;
        const nx = this.sim.wrapX(parentCell.x + DIR_DX[directionIndex]);
        const ny = parentCell.y + DIR_DY[directionIndex];

        if (!this.sim.inVerticalBounds(ny) || this.sim.cellAt(nx, ny)) {
          node.grownMask |= 1 << slot;
          this.removeFrontierAt(i);
          continue;
        }

        let blocked = false;
        for (let dx = -1; dx <= 1 && !blocked; dx++) {
          for (let dy = -1; dy <= 1; dy++) {
            if (dx === 0 && dy === 0) continue;
            const cy = ny + dy;
            if (!this.sim.inVerticalBounds(cy)) continue;
            const neighbor = this.sim.cellAt(this.sim.wrapX(nx + dx), cy);
            if (neighbor && neighbor.plant !== this) {
              blocked = true;
              break;
            }
          }
        }

        node.grownMask |= 1 << slot;
        this.removeFrontierAt(i);
        if (blocked) continue;

        const newFacing = ROTATIONS[parentCell.facing * 3 + slot];
        const child = this.sim.createStemCell(
          nx,
          ny,
          this,
          node.children[slot],
          parentCell,
          newFacing
        );
        parentCell.children.push(child);
        if (this.freeSproutUsed) this.energy -= 1;
        else this.freeSproutUsed = true;
        this.sim.stats.growthEvents++;
        return true;
      }
      return false;
    }
  }

  class TbtSimulation {
    constructor(config) {
      this.config = normalizeConfig(config);
      this.cols = this.config.cols;
      this.rows = this.config.rows;
      this.grid = new Array(this.cols * this.rows).fill(null);
      this.columnTopY = new Int32Array(this.cols);
      this.columnTopY.fill(this.rows);
      this.rng = new XorShift32(this.config.seed);
      this.tickCount = 0;
      this.nextPlantId = 1;
      this.nextCellId = 1;
      this.plants = [];
      this.travelingSeeds = [];
      this.subtreeCache = new Map();
      this.liveGenomeCounts = new Map();
      this.liveSubtreeCounts = new Map();
      this.rootsByGenome = new Map();
      this.telemetryEvents = this.newTelemetryEvents();
      this.stats = {
        births: 0,
        deaths: 0,
        failedSeeds: 0,
        mutationEvents: 0,
        mutationOperators: { bitFlip: 0, duplication: 0, deletion: 0, skipped: 0 },
        growthEvents: 0,
        energyEvents: 0,
        energyBySource: { exposure: 0, shade: 0 },
        freqDepChecks: 0,
        freqDepRejected: 0,
      };
      this.initializeSeeds();
    }

    newTelemetryEvents() {
      return {
        births: 0,
        deaths: 0,
        genomeBirths: new Map(),
        genomeDeaths: new Map(),
        subtreeBirths: new Map(),
        subtreeDeaths: new Map(),
        demography: [],
      };
    }

    subtreeComponentsForGenome(genome) {
      const hash = genomeHash(genome);
      let components = this.subtreeCache.get(hash);
      if (!components) {
        components = Object.freeze(subtreeHashes(genome, false));
        this.subtreeCache.set(hash, components);
      }
      return components;
    }

    recordPlantBirth(plant) {
      let roots = this.rootsByGenome.get(plant.hash);
      if (!roots) {
        roots = new Set();
        this.rootsByGenome.set(plant.hash, roots);
      }
      roots.add(plant);
      incrementMap(this.liveGenomeCounts, plant.hash, 1);
      incrementMap(this.telemetryEvents.genomeBirths, plant.hash, 1);
      for (let i = 0; i < plant.subtreeComponents.length; i++) {
        const hash = plant.subtreeComponents[i];
        incrementMap(this.liveSubtreeCounts, hash, 1);
        incrementMap(this.telemetryEvents.subtreeBirths, hash, 1);
      }
      this.telemetryEvents.demography.push({
        op: "birth",
        genome: plant.hash,
        subtrees: Array.from(plant.subtreeComponents),
      });
      this.telemetryEvents.births++;
    }

    recordPlantDeath(plant) {
      const roots = this.rootsByGenome.get(plant.hash);
      if (roots) {
        roots.delete(plant);
        if (!roots.size) this.rootsByGenome.delete(plant.hash);
      }
      incrementMap(this.liveGenomeCounts, plant.hash, -1);
      incrementMap(this.telemetryEvents.genomeDeaths, plant.hash, 1);
      for (let i = 0; i < plant.subtreeComponents.length; i++) {
        const hash = plant.subtreeComponents[i];
        incrementMap(this.liveSubtreeCounts, hash, -1);
        incrementMap(this.telemetryEvents.subtreeDeaths, hash, 1);
      }
      this.telemetryEvents.demography.push({
        op: "death",
        genome: plant.hash,
        subtrees: Array.from(plant.subtreeComponents),
      });
      this.telemetryEvents.deaths++;
    }

    wrapX(x) {
      if (x < 0) return x + this.cols;
      if (x >= this.cols) return x - this.cols;
      return x;
    }

    inVerticalBounds(y) {
      return y >= 0 && y < this.rows;
    }

    cellAt(x, y) {
      if (!this.inVerticalBounds(y)) return null;
      return this.grid[y * this.cols + this.wrapX(x)];
    }

    placeCell(cell) {
      const index = cell.y * this.cols + cell.x;
      if (this.grid[index]) throw new Error("Attempted to place a cell on an occupied site");
      this.grid[index] = cell;
      if (cell.y < this.columnTopY[cell.x]) this.columnTopY[cell.x] = cell.y;
    }

    removeCell(cell) {
      const index = cell.y * this.cols + cell.x;
      if (this.grid[index] === cell) this.grid[index] = null;
      if (this.columnTopY[cell.x] === cell.y) {
        let top = this.rows;
        for (let y = cell.y + 1; y < this.rows; y++) {
          if (this.grid[y * this.cols + cell.x]) {
            top = y;
            break;
          }
        }
        this.columnTopY[cell.x] = top;
      }
    }

    createCell(x, y, plant, node, parent, facing, isSeed) {
      const cell = {
        id: this.nextCellId++,
        x,
        y,
        plant,
        node,
        parent: parent || null,
        children: [],
        facing,
        isSeed: !!isSeed,
        exposureCooldown: 0,
        shadeCooldown: 0,
        depth: parent ? parent.depth + 1 : 0,
      };
      this.placeCell(cell);
      plant.registerCell(cell);
      return cell;
    }

    createStemCell(x, y, plant, node, parent, facing) {
      return this.createCell(x, y, plant, node, parent, facing, false);
    }

    createPlant(genome, x, y, startingEnergy) {
      x = this.wrapX(x | 0);
      y |= 0;
      if (!this.inVerticalBounds(y) || this.cellAt(x, y)) return null;
      const plant = new Plant(this, genome, startingEnergy);
      const facing = this.config.randomFacing ? this.rng.int(4) : 0;
      plant.seed = this.createCell(x, y, plant, plant.rootNode, null, facing, true);
      this.plants.push(plant);
      this.stats.births++;
      this.recordPlantBirth(plant);
      return plant;
    }

    initializeSeeds() {
      const count = this.config.initialSeeds;
      const halfMutated = (count / 2) | 0;
      for (let i = 0; i < count; i++) {
        let x;
        let y;
        if (count === 1) {
          x = (this.cols / 2) | 0;
          y = (this.rows / 2) | 0;
        } else {
          let attempts = 0;
          do {
            x = this.rng.int(this.cols);
            y = this.rng.int(this.rows);
            attempts++;
          } while (this.cellAt(x, y) && attempts < 1000);
          if (attempts >= 1000) continue;
        }
        const useMutation = i >= count - halfMutated;
        const genome = useMutation
          ? mutateGenome(this.config.initialGenome, this.rng, this.config)
          : new Uint8Array(this.config.initialGenome);
        this.createPlant(genome, x, y, 0);
      }
    }

    removePlantAt(index) {
      const plant = this.plants[index];
      if (!plant || plant.dead) return;
      plant.dead = true;
      this.recordPlantDeath(plant);
      for (let i = 0; i < plant.cells.length; i++) {
        const cell = plant.cells[i];
        this.removeCell(cell);
        if (cell.node) cell.node.cell = null;
      }
      plant.cells.length = 0;
      plant.frontier.length = 0;
      const last = this.plants.length - 1;
      if (index !== last) this.plants[index] = this.plants[last];
      this.plants.pop();
      this.stats.deaths++;
    }

    exposureYield(cell) {
      let open = 0;
      if (!this.cellAt(cell.x, cell.y - 1)) open++;
      if (!this.cellAt(cell.x + 1, cell.y)) open++;
      if (!this.cellAt(cell.x, cell.y + 1)) open++;
      if (!this.cellAt(cell.x - 1, cell.y)) open++;
      if (!this.config.graduatedAbsorption) return open >= 3 ? 1 : 0;
      if (open >= 3) return 1.5;
      if (open === 2) return 1;
      if (open === 1) return 0.5;
      return 0;
    }

    creditEnergy(cell, baseEnergy, source) {
      let energy = baseEnergy;
      if (this.config.distanceBonus) {
        energy *= 1 + cell.depth * this.config.distanceBonusFactor;
      }
      cell.plant.energy += energy;
      cell.plant.ticksWithoutEnergy = 0;
      this.stats.energyEvents++;
      this.stats.energyBySource[source] += energy;
    }

    advanceEnergy() {
      for (let p = 0; p < this.plants.length; p++) {
        const plant = this.plants[p];
        for (let c = 0; c < plant.cells.length; c++) {
          const cell = plant.cells[c];
          if (cell.isSeed) continue;
          if (this.config.energyExposure) {
            if (cell.exposureCooldown > 0) cell.exposureCooldown--;
            else {
              const amount = this.exposureYield(cell);
              if (amount > 0 && this.rng.float() < this.config.absorbProbability) {
                this.creditEnergy(cell, amount, "exposure");
                cell.exposureCooldown = this.config.energyCooldown;
              }
            }
          }
          if (this.config.energyShade) {
            if (cell.shadeCooldown > 0) cell.shadeCooldown--;
            else if (
              this.columnTopY[cell.x] === cell.y &&
              this.rng.float() < this.config.absorbProbability
            ) {
              this.creditEnergy(cell, 1, "shade");
              cell.shadeCooldown = this.config.energyCooldown;
            }
          }
        }
      }
    }

    createTravelingSeed(parentPlant, childGenome) {
      this.travelingSeeds.push({
        state: 0,
        parentPlant,
        childGenome: new Uint8Array(childGenome),
        currentNode: parentPlant.rootNode,
        x: 0,
        y: 0,
        stepsTaken: 0,
        dead: false,
      });
    }

    advanceReproduction() {
      const lengthAtStart = this.plants.length;
      for (let i = 0; i < lengthAtStart; i++) {
        const plant = this.plants[i];
        const parentCost = plant.genome.length;
        if (plant.reproPhase === 0) {
          if (plant.energy >= parentCost) {
            if (this.rng.float() < this.config.mutationRate) {
              const mutation = mutateGenomeDetailed(plant.genome, this.rng, this.config);
              plant.childGenome = mutation.genome;
              this.stats.mutationEvents++;
              this.stats.mutationOperators[mutation.operator]++;
              if (!mutation.changed) this.stats.mutationOperators.skipped++;
            } else {
              plant.childGenome = new Uint8Array(plant.genome);
            }
            plant.childGeneCount = plant.childGenome.length;
            plant.reproPhase = 1;
          }
        } else if (plant.energy >= parentCost + plant.childGeneCount) {
          this.createTravelingSeed(plant, plant.childGenome);
          plant.energy -= plant.childGeneCount;
          plant.reproPhase = 0;
          plant.childGenome = null;
          plant.childGeneCount = 0;
        }
      }
    }

    germinationSiteClear(x, y) {
      if (!this.inVerticalBounds(y) || this.cellAt(x, y)) return false;
      const radius = this.config.germinationClearRadius;
      for (let dx = -radius; dx <= radius; dx++) {
        for (let dy = -radius; dy <= radius; dy++) {
          if (dx === 0 && dy === 0) continue;
          const cy = y + dy;
          if (!this.inVerticalBounds(cy)) continue;
          if (this.cellAt(this.wrapX(x + dx), cy)) return false;
        }
      }
      return true;
    }

    frequencyFailureProbability(genome, x, y) {
      if (!this.config.frequencyDependence || this.config.freqDepK <= 0) return 0;
      const hash = genomeHash(genome);
      const roots = this.rootsByGenome.get(hash);
      if (!roots || !roots.size) return 0;
      const radius = this.config.freqDepRadius;
      const radiusSquared = radius * radius;
      let similarCount = 0;
      for (const plant of roots) {
        if (plant.dead || !plant.seed) continue;
        let dx = Math.abs(plant.seed.x - x);
        dx = Math.min(dx, this.cols - dx);
        const dy = plant.seed.y - y;
        if (dx * dx + dy * dy <= radiusSquared) similarCount++;
      }
      return Math.min(
        1,
        (this.config.freqDepK * similarCount) / this.config.freqDepMaxNeighbors
      );
    }

    randomWalkSeed(seed) {
      const direction = this.rng.int(4);
      if (direction === 0) seed.x = this.wrapX(seed.x - 1);
      else if (direction === 1) seed.x = this.wrapX(seed.x + 1);
      else if (direction === 2) {
        // Reflect from the sky boundary; never wrap to the bottom.
        seed.y = seed.y > 0 ? seed.y - 1 : Math.min(1, this.rows - 1);
      } else {
        // Reflect from the bottom boundary; never wrap to the top.
        seed.y = seed.y < this.rows - 1 ? seed.y + 1 : Math.max(0, this.rows - 2);
      }
    }

    advanceTravelingSeeds() {
      for (let i = this.travelingSeeds.length - 1; i >= 0; i--) {
        const seed = this.travelingSeeds[i];
        if (seed.dead) continue;
        if (seed.state === 0) {
          if (!seed.currentNode.cell || seed.parentPlant.dead) {
            seed.dead = true;
            continue;
          }
          const grownChildren = [];
          for (let slot = 0; slot < 3; slot++) {
            const child = seed.currentNode.children[slot];
            if (child && child.cell) grownChildren.push(child);
          }
          if (grownChildren.length) {
            seed.currentNode = grownChildren[this.rng.int(grownChildren.length)];
          } else {
            seed.state = 1;
            seed.x = seed.currentNode.cell.x;
            seed.y = seed.currentNode.cell.y;
            seed.stepsTaken = 0;
          }
        } else if (seed.stepsTaken >= this.config.airborneSteps) {
          if (this.germinationSiteClear(seed.x, seed.y)) {
            const failureProbability = this.frequencyFailureProbability(
              seed.childGenome,
              seed.x,
              seed.y
            );
            if (failureProbability > 0) {
              this.stats.freqDepChecks++;
            }
            if (failureProbability > 0 && this.rng.float() < failureProbability) {
              this.stats.failedSeeds++;
              this.stats.freqDepRejected++;
            } else {
              this.createPlant(
                seed.childGenome,
                seed.x,
                seed.y,
                this.config.childStartingEnergy ? seed.childGenome.length : 0
              );
            }
          } else {
            this.stats.failedSeeds++;
          }
          seed.dead = true;
        } else {
          this.randomWalkSeed(seed);
          seed.stepsTaken++;
        }
      }

      for (let i = this.travelingSeeds.length - 1; i >= 0; i--) {
        if (!this.travelingSeeds[i].dead) continue;
        const last = this.travelingSeeds.length - 1;
        if (i !== last) this.travelingSeeds[i] = this.travelingSeeds[last];
        this.travelingSeeds.pop();
      }
    }

    tick() {
      this.tickCount++;
      for (let i = this.plants.length - 1; i >= 0; i--) {
        const plant = this.plants[i];
        plant.age++;
        plant.ticksWithoutEnergy++;
        if (
          plant.age >= this.config.maxPlantAge * plant.genome.length ||
          plant.ticksWithoutEnergy >= this.config.starvationTicks
        ) {
          this.removePlantAt(i);
          continue;
        }
        plant.tryGrowOneStep();
      }
      this.advanceEnergy();
      this.advanceReproduction();
      this.advanceTravelingSeeds();
      return this;
    }

    tickMany(count) {
      count = Math.max(0, count | 0);
      for (let i = 0; i < count; i++) this.tick();
      return this;
    }

    cellCount() {
      let count = 0;
      for (let i = 0; i < this.plants.length; i++) count += this.plants[i].cells.length;
      return count;
    }

    summary() {
      const genomeTypes = new Set();
      let genomeLength = 0;
      for (let i = 0; i < this.plants.length; i++) {
        genomeTypes.add(this.plants[i].hash);
        genomeLength += this.plants[i].genome.length;
      }
      return {
        tick: this.tickCount,
        seed: this.config.seed,
        rngState: this.rng.state >>> 0,
        population: this.plants.length,
        cells: this.cellCount(),
        travelingSeeds: this.travelingSeeds.length,
        genomeTypes: genomeTypes.size,
        meanGenomeLength: this.plants.length ? genomeLength / this.plants.length : 0,
        births: this.stats.births,
        deaths: this.stats.deaths,
        failedSeeds: this.stats.failedSeeds,
        mutationEvents: this.stats.mutationEvents,
        mutationOperators: Object.assign({}, this.stats.mutationOperators),
        growthEvents: this.stats.growthEvents,
        energyEvents: this.stats.energyEvents,
        energyBySource: Object.assign({}, this.stats.energyBySource),
        freqDepChecks: this.stats.freqDepChecks,
        freqDepRejected: this.stats.freqDepRejected,
      };
    }

    telemetrySnapshot(resetEvents) {
      const events = this.telemetryEvents;
      let genomeLength = 0;
      for (let i = 0; i < this.plants.length; i++) {
        genomeLength += this.plants[i].genome.length;
      }
      const snapshot = {
        type: "sample",
        tick: this.tickCount,
        pop: this.plants.length,
        cells: this.cellCount(),
        travelingSeeds: this.travelingSeeds.length,
        births: events.births,
        deaths: events.deaths,
        meanGenomeLen: this.plants.length ? genomeLength / this.plants.length : 0,
        genomes: mapToSortedObject(this.liveGenomeCounts),
        subtrees: mapToSortedObject(this.liveSubtreeCounts),
        events: {
          genomeBirths: mapToSortedObject(events.genomeBirths),
          genomeDeaths: mapToSortedObject(events.genomeDeaths),
          subtreeBirths: mapToSortedObject(events.subtreeBirths),
          subtreeDeaths: mapToSortedObject(events.subtreeDeaths),
          demography: events.demography,
        },
      };
      if (resetEvents !== false) this.telemetryEvents = this.newTelemetryEvents();
      return snapshot;
    }

    stateDigest() {
      let hash = 0x811c9dc5;
      function mix(value) {
        value >>>= 0;
        for (let i = 0; i < 4; i++) {
          hash ^= value & 0xff;
          hash = Math.imul(hash, 0x01000193) >>> 0;
          value >>>= 8;
        }
      }
      mix(this.tickCount);
      mix(this.rng.state);
      mix(this.plants.length);
      mix(this.travelingSeeds.length);
      const ordered = this.plants.slice().sort((a, b) => a.id - b.id);
      for (let i = 0; i < ordered.length; i++) {
        const plant = ordered[i];
        mix(plant.id);
        mix(plant.age);
        mix(plant.ticksWithoutEnergy);
        mix(plant.reproPhase);
        mix(plant.freeSproutUsed ? 1 : 0);
        mix((plant.energy * 1000000) | 0);
        mix(plant.genome.length);
        for (let g = 0; g < plant.genome.length; g++) mix(plant.genome[g]);
        const cells = plant.cells.slice().sort((a, b) => a.id - b.id);
        mix(cells.length);
        for (let c = 0; c < cells.length; c++) {
          mix(cells[c].x);
          mix(cells[c].y);
          mix(cells[c].facing);
          mix(cells[c].isSeed ? 1 : 0);
          mix(cells[c].exposureCooldown);
          mix(cells[c].shadeCooldown);
          mix(cells[c].parent ? cells[c].parent.id : 0);
        }
      }
      for (let i = 0; i < this.travelingSeeds.length; i++) {
        const seed = this.travelingSeeds[i];
        mix(seed.state);
        mix(seed.parentPlant ? seed.parentPlant.id : 0);
        mix(seed.x);
        mix(seed.y);
        mix(seed.stepsTaken);
        mix(seed.childGenome.length);
        for (let g = 0; g < seed.childGenome.length; g++) mix(seed.childGenome[g]);
      }
      return hash.toString(16).padStart(8, "0");
    }
  }

  return Object.freeze({
    TbtSimulation,
    XorShift32,
    GeneNode,
    DEFAULT_CONFIG,
    DEFAULT_GENOME,
    SLOT_LEFT,
    SLOT_UP,
    SLOT_RIGHT,
    SLOT_MASKS,
    DIR_DX,
    DIR_DY,
    ROTATIONS,
    decodeGenomeToTree,
    encodeTreeToGenome,
    canonicalGenome,
    collectNodesPreorder,
    cloneSubtree,
    genomeHash,
    subtreeHashes,
    incrementMap,
    mapToSortedObject,
    mutateBitFlip,
    mutateSubtreeDuplication,
    mutateSubtreeDeletion,
    mutateGenomeDetailed,
    mutateGenome,
    plantColorFromGenome,
  });
});
