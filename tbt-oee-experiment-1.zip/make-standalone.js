#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

function safeInline(source) {
  return source.replace(/<\/script/gi, "<\\/script");
}

const directory = __dirname;
const template = fs.readFileSync(path.join(directory, "browser.html"), "utf8");
const core = safeInline(fs.readFileSync(path.join(directory, "sim-core.js"), "utf8"));
const view = safeInline(fs.readFileSync(path.join(directory, "browser-view.js"), "utf8"));
const output = template
  .replace('<script src="sim-core.js"></script>', `<script>\n${core}\n</script>`)
  .replace('<script src="browser-view.js"></script>', `<script>\n${view}\n</script>`);
const outputPath = path.join(directory, "tbt-oee-standalone-1.html");
fs.writeFileSync(outputPath, output, "utf8");
process.stdout.write(outputPath + "\n");

