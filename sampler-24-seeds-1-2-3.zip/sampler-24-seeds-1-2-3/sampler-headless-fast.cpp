#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <memory>
#include <sstream>
#include <string>
#include <unordered_set>
#include <utility>
#include <vector>

using std::shared_ptr;
using std::vector;
namespace fs = std::filesystem;

static constexpr int W=440,H=735,N=W*H,HUES=256;
static constexpr double UPKEEP=.004,SENESCE=200,AGE_COST=.60,MARK_COST=.25;
static constexpr double SEED_ENERGY=4,SEED_COST=7,STARVE_DEBT=25,PHOTO=.02;
static constexpr int BLK=16,SEED_WALK=55,SEED_LIFE=900,GERM_CLEAR=3;
static constexpr double MUT_P=.35,HUE_MUT=.25,NOVELTY=.5,MUT_P2=.25;
static constexpr int GRACE=0,PATIENCE=0,HUE_STEP=14,MAX_NODES=20;
static constexpr int OPEN=0,LIVE=1,SEED_CELL=2,TISSUE=0,PETAL=1,CORE=2;
static constexpr int DX[8]={0,1,1,1,0,-1,-1,-1};
static constexpr int DY[8]={-1,-1,0,1,1,1,0,-1};

struct Node {
  char k='F'; int turn=0,len=0; vector<shared_ptr<Node>> ch;
};
struct Genome { shared_ptr<Node> root; int hue=0; };
struct Job { shared_ptr<Node> node; int x,y,dir,d; };
struct Flower { int x,y; vector<int> cells; };
struct Plant;
struct Seed;

static shared_ptr<Node> cloneNode(const shared_ptr<Node>& n){
  auto c=std::make_shared<Node>(); c->k=n->k;c->turn=n->turn;c->len=n->len;
  c->ch.reserve(n->ch.size()); for(auto &x:n->ch)c->ch.push_back(cloneNode(x)); return c;
}
static int nodeSize(const shared_ptr<Node>& n){int z=1;for(auto &x:n->ch)z+=nodeSize(x);return z;}
static void formCodeRec(const shared_ptr<Node>& n,std::string& s){
  if(n->k=='F'){s+='f';return;} s+='s';s+=std::to_string(n->turn);s+=std::to_string(n->len);s+='(';
  for(auto &x:n->ch)formCodeRec(x,s);s+=')';
}
static std::string formCode(const shared_ptr<Node>& n){std::string s;formCodeRec(n,s);return s;}

struct Sim {
  uint32_t worldSeed,rngState;
  vector<uint8_t> kind,role,hueAt;
  vector<uint16_t> owner;
  vector<Plant> plants;
  vector<Seed> seeds;
  vector<uint16_t> freeIds;
  uint32_t nextId=1;
  int tick=0,generation=0,born=0,died=0,recolonised=0;
  int bw=(W+BLK-1)/BLK,bh=(H+BLK-1)/BLK,bloomCount=0;
  bool meanDefined=false;
  double meanHue=0;
  vector<double> hueCos,hueSin,blockCos,blockSin;
  vector<int> blockN;
  Genome ancestor;

  explicit Sim(uint32_t seed);
  inline int idx(int x,int y)const{return y*W+x;}
  inline bool inB(int x,int y)const{return x>=0&&y>=0&&x<W&&y<H;}
  inline bool passable(int x,int y)const{return inB(x,y)&&kind[idx(x,y)]==OPEN;}
  inline double rand01(){rngState^=rngState<<13;rngState^=rngState>>17;rngState^=rngState<<5;return double(rngState)/4294967296.0;}
  inline int randInt(int n){return int(rand01()*n);}
  inline int newTurn(){return randInt(3)-1;}
  uint16_t takeId(){if(!freeIds.empty()){auto x=freeIds.back();freeIds.pop_back();return x;}return nextId<65535?uint16_t(nextId++):1;}
  void mutate(shared_ptr<Node>& root);
  Genome breed(const Genome& parent);
  void tallyBlooms();
  double localHue(const Plant& p)const;
  void colonise(int n);
  void step();
  void capture(const fs::path& out,int checkpoint)const;
};

struct Plant {
  Sim* s=nullptr; uint16_t id=0; Genome genome; std::string code;
  int gen=0,age=0,openFaces=0,sterileAge=0,baseX=0,baseY=0,marks=0;
  double energy=SEED_ENERGY; bool done=false;
  vector<Job> queue; vector<int> cells; vector<Flower> flowers;
  Plant()=default;
  Plant(Sim* sim,const Genome& g,int x,int y,int generation):s(sim),id(sim->takeId()),genome(g),code(formCode(g.root)),gen(generation),baseX(x),baseY(y){
    if(gen>s->generation)s->generation=gen;queue.push_back({g.root,x,y,0,0});s->born++;
  }
  bool fits(const vector<int>& pairs,bool strict,int dir=-1)const;
  void write(const vector<int>& pairs,int r,int d);
  double costOf(const Job& job)const{return (job.node->k=='F'?5:job.node->len)*MARK_COST;}
  void grow(); bool place(const Job& job,double cost);
  void photosynthesize(){energy+=openFaces*PHOTO;}
  void sow();
  bool upkeep(){age++;double a=age/SENESCE;energy-=cells.size()*UPKEEP+a*a*AGE_COST;if(done&&flowers.empty()&&++sterileAge>GRACE)return true;return energy < -STARVE_DEBT;}
  void die(){for(int j:cells)if(s->kind[j]==LIVE&&s->owner[j]==id){s->owner[j]=0;s->role[j]=0;s->kind[j]=OPEN;}s->freeIds.push_back(id);s->died++;}
};

struct Seed {
  Sim* s=nullptr; Genome genome; int gen=0,age=0,steps=0,i=-1,x=0,y=0;
  Seed()=default;
  Seed(Sim* sim,const Genome& g,int xx,int yy,int generation):s(sim),genome(g),gen(generation),steps(20+sim->randInt(SEED_WALK)),x(xx),y(yy){}
  void occupy(){if(s->passable(x,y)){i=s->idx(x,y);s->kind[i]=SEED_CELL;}}
  bool settled()const{auto k=s->kind[s->idx(x,y)];return k==SEED_CELL||k==OPEN;}
  void release(){if(i>=0&&s->kind[i]==SEED_CELL)s->kind[i]=OPEN;i=-1;}
  bool stepOne();
};

Sim::Sim(uint32_t seed):worldSeed(seed?seed:1),rngState(seed?seed:1),kind(N),role(N),hueAt(N),owner(N),hueCos(HUES),hueSin(HUES),blockCos(bw*bh),blockSin(bw*bh),blockN(bw*bh){
  for(int h=0;h<HUES;h++){double a=2*M_PI*h/HUES;hueCos[h]=cos(a);hueSin[h]=sin(a);}
  auto f=std::make_shared<Node>();f->k='F';f->turn=0;
  auto r=std::make_shared<Node>();r->k='S';r->turn=0;r->len=3;r->ch={f};ancestor={r,0};
  colonise(40);
}

void Sim::mutate(shared_ptr<Node>& root){
  struct E{Node* n;Node* p;};vector<E> nodes;
  auto walk=[&](auto&& self,Node* n,Node* p)->void{nodes.push_back({n,p});for(auto &c:n->ch)self(self,c.get(),n);};walk(walk,root.get(),nullptr);
  double roll=rand01();
  if(roll<.20&&nodeSize(root)<MAX_NODES){
    vector<E> cand;for(auto e:nodes)if(e.n->k=='S'&&e.n->ch.size()<3)cand.push_back(e);
    int hi=randInt((int)cand.size()); E* host=cand.empty()?nullptr:&cand[hi];
    if(host){int ni=randInt((int)nodes.size());auto limb=cloneNode(shared_ptr<Node>(root,nodes[ni].n));
      if(nodeSize(root)+nodeSize(limb)<=MAX_NODES){limb->turn=newTurn();host->n->ch.push_back(limb);return;}}
  }
  if(roll<.34){
    vector<E> cand;for(auto e:nodes)if(e.p)cand.push_back(e);int vi=randInt((int)cand.size());E* victim=cand.empty()?nullptr:&cand[vi];
    if(victim){auto &v=victim->p->ch;auto it=std::find_if(v.begin(),v.end(),[&](auto &p){return p.get()==victim->n;});if(it!=v.end())v.erase(it);return;}
  }
  E e=nodes[randInt((int)nodes.size())];Node* n=e.n;
  if(n->k=='S'){
    vector<int> fields={0};if(e.p)fields.push_back(1);if(e.p&&n->ch.empty())fields.push_back(2);int f=fields[randInt((int)fields.size())];
    if(f==1)n->turn=std::max(-3,std::min(3,n->turn+(rand01()<.5?-1:1)));
    else if(f==0)n->len=std::max(2,std::min(7,n->len+(rand01()<.5?-1:1)));
    else {n->k='F';n->len=0;}
  }else{n->k='S';n->turn=newTurn();n->len=2+randInt(4);n->ch.clear();auto f=std::make_shared<Node>();f->k='F';n->ch.push_back(f);}
}

Genome Sim::breed(const Genome& parent){
  Genome g=parent;
  if(rand01()<MUT_P){g.root=cloneNode(parent.root);mutate(g.root);if(rand01()<MUT_P2)mutate(g.root);}
  if(rand01()<HUE_MUT)g.hue=(g.hue+HUES+randInt(2*HUE_STEP+1)-HUE_STEP)%HUES;
  return g;
}

bool Plant::fits(const vector<int>& pairs,bool strict,int dir)const{
  int fresh=0;std::unordered_set<int> proposed;proposed.reserve(pairs.size()/2*2);
  for(size_t i=0;i<pairs.size();i+=2)if(s->inB(pairs[i],pairs[i+1]))proposed.insert(s->idx(pairs[i],pairs[i+1]));
  for(size_t i=0;i<pairs.size();i+=2){int x=pairs[i],y=pairs[i+1];if(!s->inB(x,y))return false;int j=s->idx(x,y);
    if(s->kind[j]==LIVE){if(s->owner[j]!=id)return false;if(strict)return false;continue;}if(s->kind[j]==SEED_CELL)return false;fresh++;
    for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){int nx=x+dx,ny=y+dy;if(!s->inB(nx,ny))continue;int m=s->idx(nx,ny);if(s->kind[m]==LIVE&&s->owner[m]!=id)return false;}
  }
  if(dir>=0){int pd=(dir+2)&7,px=DX[pd],py=DY[pd];auto mine=[&](int x,int y){if(!s->inB(x,y))return false;int j=s->idx(x,y);return proposed.count(j)||(s->kind[j]==LIVE&&s->owner[j]==id);};
    for(size_t i=0;i<pairs.size();i+=2){int x=pairs[i],y=pairs[i+1],wide=1;for(int sg:{-1,1})for(int k=1;k<=3;k++){if(!mine(x+px*k*sg,y+py*k*sg))break;if(++wide>3)return false;}}
  }
  return fresh>0;
}

void Plant::write(const vector<int>& pairs,int r,int){
  for(size_t i=0;i<pairs.size();i+=2){int x=pairs[i],y=pairs[i+1],j=s->idx(x,y);if(s->kind[j]==LIVE)continue;int freshFaces=0;
    for(int q=0;q<8;q++){int nx=x+DX[q],ny=y+DY[q];if(!s->inB(nx,ny)||s->kind[s->idx(nx,ny)]!=LIVE){freshFaces++;continue;}int m=s->idx(nx,ny);if(s->owner[m]==id&&s->role[m]==TISSUE)openFaces--;}
    s->kind[j]=LIVE;s->role[j]=r;s->owner[j]=id;s->hueAt[j]=genome.hue;if(r==TISSUE)openFaces+=freshFaces;cells.push_back(j);
  }
}

void Plant::grow(){
  if(done)return;int guard=0;while(!queue.empty()&&guard++<8){Job job=queue.front();double cost=costOf(job);if(energy<cost)return;queue.erase(queue.begin());if(place(job,cost)){marks++;return;}}
  if(queue.empty())done=true;
}

bool Plant::place(const Job& job,double cost){
  auto n=job.node;int x=job.x,y=job.y,dir=job.dir,d=job.d;
  if(n->k=='F'){
    int sx=x-DX[dir],sy=y-DY[dir],fx=0,fy=0;vector<int> petals,cores;int pd=(dir+2)&7;vector<std::pair<int,int>> candidates;
    for(int k=1;k<=2;k++)candidates.push_back({k,0});for(int k=1;k<=2;k++){candidates.push_back({k,-1});candidates.push_back({k,1});}
    for(auto [k,q]:candidates){int cx=x+DX[dir]*(k-1)+DX[pd]*q,cy=y+DY[dir]*(k-1)+DY[pd]*q;vector<int> pp={cx,cy-1,cx+1,cy,cx,cy+1,cx-1,cy},cc={cx,cy};
      bool onTip=false,touching=false;vector<int> all=pp;all.insert(all.end(),cc.begin(),cc.end());for(size_t i=0;i<all.size();i+=2){int ax=abs(all[i]-sx),ay=abs(all[i+1]-sy);if(ax==0&&ay==0)onTip=true;else if(ax+ay==1)touching=true;}
      if(!onTip&&touching){fx=cx;fy=cy;petals=std::move(pp);cores=std::move(cc);break;}}
    if(petals.empty())return false;vector<int> all=petals;all.insert(all.end(),cores.begin(),cores.end());if(!fits(all,true))return false;write(petals,PETAL,d);write(cores,CORE,d);
    Flower fl{fx,fy,{}};for(size_t i=0;i<petals.size();i+=2)fl.cells.push_back(s->idx(petals[i],petals[i+1]));for(size_t i=0;i<cores.size();i+=2)fl.cells.push_back(s->idx(cores[i],cores[i+1]));flowers.push_back(std::move(fl));energy-=cost;return true;
  }
  vector<int> spine;spine.reserve(n->len*2);for(int i=0;i<n->len;i++){spine.push_back(x+DX[dir]*i);spine.push_back(y+DY[dir]*i);}if(!fits(spine,false,dir))return false;
  for(size_t i=0;i<spine.size();i+=2)write({spine[i],spine[i+1]},TISSUE,d+(i>>1));energy-=cost;int tx=spine[spine.size()-2],ty=spine.back();
  for(auto &child:n->ch){int cd=(dir+child->turn+8)&7;queue.push_back({child,tx+DX[cd],ty+DY[cd],cd,d+n->len});}return true;
}

void Plant::sow(){
  if(!done||flowers.empty())return;double near=s->localHue(*this);double delta=near<0?0:std::abs(genome.hue-near);double dg=near<0?0:std::min(delta,HUES-delta);double odd=near<0?0:dg/(HUES/2.0);double cost=SEED_COST*(1-NOVELTY*odd);
  for(auto &h:flowers){if(energy<cost)return;energy-=cost;Genome g=s->breed(genome);s->seeds.emplace_back(s,g,h.x,h.y,gen+1);}
}

bool Seed::stepOne(){
  age++;if(age>SEED_LIFE){release();return false;}if(steps>0){steps--;int d=s->randInt(8),nx=x+DX[d],ny=y+DY[d];if(s->inB(nx,ny)){x=nx;y=ny;}if(steps==0&&!s->passable(x,y))steps=4;return true;}
  occupy();if(!settled()){steps=4;return true;}
  for(int dy=-GERM_CLEAR;dy<=GERM_CLEAR;dy++)for(int dx=-GERM_CLEAR;dx<=GERM_CLEAR;dx++){int nx=x+dx,ny=y+dy;if(!s->inB(nx,ny))continue;if(s->kind[s->idx(nx,ny)]==LIVE){if(age<PATIENCE)return true;release();return false;}}
  release();Plant pl(s,genome,x,y,gen);pl.grow();if(pl.cells.empty()){s->born--;s->freeIds.push_back(pl.id);occupy();return true;}s->plants.push_back(std::move(pl));return false;
}

void Sim::tallyBlooms(){
  std::fill(blockCos.begin(),blockCos.end(),0);std::fill(blockSin.begin(),blockSin.end(),0);std::fill(blockN.begin(),blockN.end(),0);double sx=0,sy=0;int n=0;
  for(auto &p:plants){if(!p.done||p.flowers.empty())continue;int heads=p.flowers.size(),h=p.genome.hue,b=(p.baseY/BLK)*bw+p.baseX/BLK;blockCos[b]+=hueCos[h]*heads;blockSin[b]+=hueSin[h]*heads;blockN[b]+=heads;sx+=hueCos[h]*heads;sy+=hueSin[h]*heads;n+=heads;}
  bloomCount=n;meanDefined=n>0&&std::hypot(sx,sy)>1e-9;if(meanDefined)meanHue=fmod(atan2(sy,sx)*HUES/(2*M_PI)+HUES,HUES);
}

double Sim::localHue(const Plant& p)const{
  int bx=p.baseX/BLK,by=p.baseY/BLK,n=0;double sx=0,sy=0;for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){int nx=bx+dx,ny=by+dy;if(nx<0||ny<0||nx>=bw||ny>=bh)continue;int b=ny*bw+nx;sx+=blockCos[b];sy+=blockSin[b];n+=blockN[b];}
  int heads=p.flowers.size(),h=p.genome.hue;sx-=hueCos[h]*heads;sy-=hueSin[h]*heads;n-=heads;if(n<=0||std::hypot(sx,sy)<1e-9)return -1;return fmod(atan2(sy,sx)*HUES/(2*M_PI)+HUES,HUES);
}

void Sim::colonise(int n){
  int tries=0,placed=0;while(placed<n&&tries<n*200){tries++;int x=5+randInt(W-10),y=8+randInt(H-16);if(kind[idx(x,y)]!=OPEN)continue;bool clear=true;for(auto &p:plants)if(abs(p.baseX-x)<12&&abs(p.baseY-y)<14){clear=false;break;}if(!clear)continue;seeds.emplace_back(this,ancestor,x,y,0);seeds.back().steps=0;placed++;}
}

void Sim::step(){
  tick++;tallyBlooms();for(int i=(int)plants.size()-1;i>=0;i--){auto &p=plants[i];p.photosynthesize();p.grow();p.sow();if(p.cells.empty()||p.upkeep()){p.die();p.s=nullptr;}}
  plants.erase(std::remove_if(plants.begin(),plants.end(),[](auto &p){return p.s==nullptr;}),plants.end());
  for(int i=(int)seeds.size()-1;i>=0;i--)if(!seeds[i].stepOne())seeds[i].s=nullptr;
  seeds.erase(std::remove_if(seeds.begin(),seeds.end(),[](auto &x){return x.s==nullptr;}),seeds.end());
  if(plants.empty()&&seeds.empty()&&tick%400==0){colonise(6);recolonised++;}
}

static void jsonNode(std::ostream& o,const shared_ptr<Node>& n){o<<"{\"k\":\""<<n->k<<"\",\"turn\":"<<n->turn;if(n->k=='S')o<<",\"len\":"<<n->len;o<<",\"ch\":[";for(size_t i=0;i<n->ch.size();i++){if(i)o<<',';jsonNode(o,n->ch[i]);}o<<"]}";}
static std::string tagTick(int t){if(t==1000000)return "1000000";if(t>=1000)return std::to_string(t/1000)+"k";return std::to_string(t);}

void Sim::capture(const fs::path& out,int checkpoint)const{
  std::string tag="seed-"+std::to_string(worldSeed)+"_tick-"+tagTick(checkpoint);fs::create_directories(out/"raw");fs::create_directories(out/"state");
  std::map<std::pair<std::string,int>,int> genotypeIds;vector<Genome> genotypes;
  auto genotypeId=[&](const Genome& g){auto key=std::make_pair(formCode(g.root),g.hue);auto it=genotypeIds.find(key);if(it!=genotypeIds.end())return it->second;int id=genotypes.size();genotypeIds.emplace(std::move(key),id);genotypes.push_back(g);return id;};
  for(auto &p:plants)genotypeId(p.genome);for(auto &q:seeds)genotypeId(q.genome);
  std::ofstream ppm(out/"raw"/(tag+".ppm"),std::ios::binary);ppm<<"P6\n"<<W<<" "<<H<<"\n255\n";
  auto rgb=[&](int j){std::array<uint8_t,3> c{};if(kind[j]==OPEN)return c;if(kind[j]==SEED_CELL)return std::array<uint8_t,3>{0x2a,0x1e,0x15};if(role[j]==TISSUE)return std::array<uint8_t,3>{0xc2,0xd0,0x9b};if(role[j]==CORE)return std::array<uint8_t,3>{0xf4,0xe8,0xcc};int h=hueAt[j];double sv=.62,v=.88,cc=v*sv,hp=h/256.0*6,xx=cc*(1-std::abs(fmod(hp,2)-1)),m=v-cc,r=0,g=0,b=0;if(hp<1){r=cc;g=xx;}else if(hp<2){r=xx;g=cc;}else if(hp<3){g=cc;b=xx;}else if(hp<4){g=xx;b=cc;}else if(hp<5){r=xx;b=cc;}else{r=cc;b=xx;}return std::array<uint8_t,3>{uint8_t((r+m)*255),uint8_t((g+m)*255),uint8_t((b+m)*255)};};
  for(int j=0;j<N;j++){auto c=rgb(j);ppm.write((char*)c.data(),3);}ppm.close();
  int tissue=0,petals=0,cores=0,seedcells=0;for(int j=0;j<N;j++){if(kind[j]==SEED_CELL)seedcells++;else if(kind[j]==LIVE){if(role[j]==TISSUE)tissue++;else if(role[j]==PETAL)petals++;else cores++;}}
  std::ofstream o(out/"state"/(tag+".json"));o<<std::setprecision(17)<<"{\"schema\":\"sampler-24-headless-state-v2\",\"seed\":"<<worldSeed<<",\"rng_state\":"<<rngState<<",\"tick\":"<<tick<<",\"width\":"<<W<<",\"height\":"<<H<<",\"pixel_size\":1,\"totals\":{\"plants\":"<<plants.size()<<",\"seeds\":"<<seeds.size()<<",\"born\":"<<born<<",\"died\":"<<died<<",\"recolonised\":"<<recolonised<<",\"max_generation\":"<<generation<<",\"blooms\":"<<bloomCount<<",\"mean_hue\":";
  if(meanDefined)o<<meanHue;else o<<"null";o<<",\"tissue\":"<<tissue<<",\"petal\":"<<petals<<",\"core\":"<<cores<<",\"seed_cell\":"<<seedcells<<"},\"genotypes\":[";for(size_t z=0;z<genotypes.size();z++){if(z)o<<',';auto &g=genotypes[z];o<<"{\"id\":"<<z<<",\"hue\":"<<g.hue<<",\"form_code\":\""<<formCode(g.root)<<"\",\"genome\":";jsonNode(o,g.root);o<<'}';}o<<"],\"plants\":[";
  for(size_t z=0;z<plants.size();z++){if(z)o<<',';auto &p=plants[z];int minx=W,miny=H,maxx=-1,maxy=-1,tc=0,pc=0,cc=0;for(int j:p.cells){int x=j%W,y=j/W;minx=std::min(minx,x);maxx=std::max(maxx,x);miny=std::min(miny,y);maxy=std::max(maxy,y);if(role[j]==TISSUE)tc++;else if(role[j]==PETAL)pc++;else cc++;}
    o<<"{\"id\":"<<p.id<<",\"generation\":"<<p.gen<<",\"age\":"<<p.age<<",\"energy\":"<<p.energy<<",\"open_faces\":"<<p.openFaces<<",\"done\":"<<(p.done?"true":"false")<<",\"pending_jobs\":"<<p.queue.size()<<",\"marks\":"<<p.marks<<",\"sterile_age\":"<<p.sterileAge<<",\"base\":["<<p.baseX<<','<<p.baseY<<"],\"bbox\":["<<minx<<','<<miny<<','<<maxx<<','<<maxy<<"],\"cell_count\":"<<p.cells.size()<<",\"tissue_cells\":"<<tc<<",\"petal_cells\":"<<pc<<",\"core_cells\":"<<cc<<",\"flower_count\":"<<p.flowers.size()<<",\"flower_centers\":[";for(size_t q=0;q<p.flowers.size();q++){if(q)o<<',';o<<'['<<p.flowers[q].x<<','<<p.flowers[q].y<<']';}o<<"],\"genotype_id\":"<<genotypeId(p.genome)<<",\"hue\":"<<p.genome.hue<<",\"form_code\":\""<<p.code<<"\",\"cells\":[";for(size_t q=0;q<p.cells.size();q++){if(q)o<<',';o<<p.cells[q];}o<<"]}";}
  o<<"],\"seeds\":[";for(size_t z=0;z<seeds.size();z++){if(z)o<<',';auto &q=seeds[z];o<<"{\"index\":"<<z<<",\"generation\":"<<q.gen<<",\"age\":"<<q.age<<",\"steps_remaining\":"<<q.steps<<",\"position\":["<<q.x<<','<<q.y<<"],\"occupied_cell\":"<<q.i<<",\"genotype_id\":"<<genotypeId(q.genome)<<",\"hue\":"<<q.genome.hue<<",\"form_code\":\""<<formCode(q.genome.root)<<"\"}";}o<<"]}";o.close();
  std::ofstream pcsv(out/"state"/(tag+"_plants.csv"));pcsv<<"id,generation,age,energy,open_faces,done,pending_jobs,marks,sterile_age,base_x,base_y,min_x,min_y,max_x,max_y,cell_count,flower_count,hue,form_code\n"<<std::setprecision(17);for(auto &p:plants){int minx=W,miny=H,maxx=-1,maxy=-1;for(int j:p.cells){int x=j%W,y=j/W;minx=std::min(minx,x);maxx=std::max(maxx,x);miny=std::min(miny,y);maxy=std::max(maxy,y);}pcsv<<p.id<<','<<p.gen<<','<<p.age<<','<<p.energy<<','<<p.openFaces<<','<<p.done<<','<<p.queue.size()<<','<<p.marks<<','<<p.sterileAge<<','<<p.baseX<<','<<p.baseY<<','<<minx<<','<<miny<<','<<maxx<<','<<maxy<<','<<p.cells.size()<<','<<p.flowers.size()<<','<<p.genome.hue<<','<<p.code<<'\n';}
  struct A{std::string code;int hue=0,count=0,minc=INT32_MAX,maxc=0,ming=INT32_MAX,maxg=0;double cells=0,flowers=0,energy=0;};std::map<std::pair<std::string,int>,A> mm;for(auto&p:plants){auto k=std::make_pair(p.code,p.genome.hue);auto&a=mm[k];a.code=p.code;a.hue=p.genome.hue;a.count++;a.cells+=p.cells.size();a.flowers+=p.flowers.size();a.energy+=p.energy;a.minc=std::min(a.minc,(int)p.cells.size());a.maxc=std::max(a.maxc,(int)p.cells.size());a.ming=std::min(a.ming,p.gen);a.maxg=std::max(a.maxg,p.gen);}vector<A> aa;for(auto&[k,a]:mm)aa.push_back(a);std::sort(aa.begin(),aa.end(),[](auto&a,auto&b){return a.count!=b.count?a.count>b.count:a.cells/a.count>b.cells/b.count;});std::ofstream fc(out/"state"/(tag+"_forms.csv"));fc<<"form_code,hue,count,mean_cells,min_cells,max_cells,mean_flowers,mean_energy,min_generation,max_generation\n"<<std::setprecision(17);for(auto&a:aa)fc<<a.code<<','<<a.hue<<','<<a.count<<','<<a.cells/a.count<<','<<a.minc<<','<<a.maxc<<','<<a.flowers/a.count<<','<<a.energy/a.count<<','<<a.ming<<','<<a.maxg<<'\n';
}

int main(int argc,char**argv){
  if(argc<4){std::cerr<<"usage: sampler-headless-fast SEED OUTPUT CHECKPOINTS\n";return 2;}uint32_t seed=std::stoul(argv[1]);fs::path out=argv[2];vector<int> cps;std::stringstream ss(argv[3]);std::string x;while(std::getline(ss,x,','))cps.push_back(std::stoi(x));Sim sim(seed);for(int cp:cps){auto t0=std::chrono::steady_clock::now();while(sim.tick<cp)sim.step();sim.tallyBlooms();sim.capture(out,cp);auto ms=std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now()-t0).count();int cells=0;for(auto&p:sim.plants)cells+=p.cells.size();std::cout<<"{\"seed\":"<<seed<<",\"tick\":"<<cp<<",\"elapsed_ms\":"<<ms<<",\"plants\":"<<sim.plants.size()<<",\"seeds\":"<<sim.seeds.size()<<",\"cells\":"<<cells<<",\"generation\":"<<sim.generation<<"}"<<std::endl;}}
