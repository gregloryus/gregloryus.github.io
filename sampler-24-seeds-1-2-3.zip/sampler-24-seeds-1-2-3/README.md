# Sampler 24 headless experiment

This package contains exact visual and structured snapshots of `sampler-24.html` for world seeds 1, 2, and 3 at ticks 10, 100, 1,000, 10,000, 100,000, and 1,000,000.

## Experimental setup

- World: 440 × 735 cells
- Render scale: 1 pixel per cell
- Starting population: 40 copies of the red common ancestor
- All other parameters: the defaults embedded in `sampler-24.html`
- Recolonization: enabled, as in the source default
- Capture convention: each labeled tick is captured after exactly that many calls to the simulation's `step()` logic. Bloom tallies are refreshed before the state is serialized.
- Images contain only the canvas. The HUD and control bar are excluded.

This deliberately interprets “440×735 1px” as an explicit 440×735-cell world (`w=440&h=735&px=1`), not as a 440×735 browser viewport whose control bar would reduce the world height.

## Package map

- `images/`: the 18 original-resolution PNG snapshots.
- `image-index.html`: a simple browsable gallery linking to every exact PNG.
- `state/*_plants.csv`: one row per living plant at a checkpoint.
- `state/*_forms.csv`: living plants aggregated by morphology plus hue.
- `state/*.json`: the richest snapshot data, including every living plant, every active seed, deduplicated genotype trees, flower centers, bounding boxes, and occupied cell indices.
- `metrics.csv`: global metrics for all 18 snapshots.
- `hues.csv`: checkpoint-level hue summaries across living plants.
- `manifest.json`: file sizes and SHA-256 hashes.
- `sampler-24.html`: the original simulation supplied for the experiment.
- `sampler-headless-fast.cpp`: the accelerated, deterministic headless implementation used for the long runs.
- `run-sampler-headless.js`: a slower harness that executes the original inline JavaScript directly and was used as the reference validator.
- `postprocess-sampler.js`: converts lossless raw frames to PNG and builds the consolidated summaries and gallery.
- `REPORT-BRIEF.md`: suggested instructions for the AI creating the visual report.

## Reading the images

- Black: open ground.
- Pale green: living tissue. Exposure affects metabolism, never its rendered color.
- Cream: flower core.
- Colored pixels: flower petals. Hue is the plant's heritable 0–255 circular hue value.
- Brown: a settled seed cell.
- Airborne seeds are intentionally invisible in the source renderer. Their positions and states remain available in JSON.

## Structured-state schema

Each JSON file uses `sampler-24-headless-state-v2`:

- `totals`: population, births, deaths, recolonizations, maximum generation, bloom count, circular mean hue, and rendered cell counts.
- `genotypes`: deduplicated genotype records. Each contains `hue`, `form_code`, and the exact recursive genome tree.
- `plants`: one record per living plant. `genotype_id` points into `genotypes`; `cells` contains every occupied flattened cell index; `bbox` is inclusive.
- `seeds`: one record per active seed, including generation, age, remaining random-walk steps, position, and genotype.

Convert a flattened cell index `j` back to coordinates with `x = j % 440` and `y = floor(j / 440)`.

The morphology signature grammar is recursive:

- `f`: a flower instruction.
- `sTURNLENGTH(CHILDREN...)`: a stroke instruction, followed by its child instructions.

For example, `s03(f)` is a length-3 straight stroke ending in a flower. Negative turns appear with a minus sign.

## Exactness and validation

The long runs use a data-oriented C++ implementation because direct execution of three million JavaScript ticks would take hours. Before the full run, it was cross-checked against the original JavaScript at ticks 10, 100, 1,000, and 10,000 for seed 1. At every validation checkpoint, these matched exactly:

- RNG state
- global totals
- every plant's identity, genotype, age, geometry, and occupied cells
- every seed's genotype, age, position, and movement state
- every rendered RGB pixel

The original HTML and both runners are included so the experiment is auditable and reproducible.

## Important analytical limits

- The source model does not retain parent IDs or dead organisms. Generation and genotype are recorded, but a literal parent-child lineage tree cannot be reconstructed after the run.
- These are six cross-sectional snapshots per seed, not a continuous event log. A form that rises and disappears between checkpoints will be missed.
- “Species” must be used cautiously. Reproduction is clonal and there is no mating barrier, recombination, or explicit species identity. Morphological, hue, spatial, or ecological clusters can still be analyzed as proto-lineages or ecotypes.
- Color has direct local negative frequency-dependent selection through seed cost. Color patterns are therefore emergent spatial outcomes of an explicit frequency-dependent rule, not evidence that color selection itself appeared spontaneously.
- The model contains competition and frequency dependence, but no explicit consumer-resource, mutualistic, or host-parasite coupling. Claims of co-evolution require evidence of reciprocal adaptive change between distinguishable lineages, not merely coexistence or local color divergence.

## Reproduction

From a directory containing the included files:

```bash
g++ -O3 -march=native -std=c++20 sampler-headless-fast.cpp -o sampler-headless-fast
./sampler-headless-fast 1 output 10,100,1000,10000,100000,1000000
./sampler-headless-fast 2 output 10,100,1000,10000,100000,1000000
./sampler-headless-fast 3 output 10,100,1000,10000,100000,1000000
node postprocess-sampler.js output
```

`postprocess-sampler.js` requires the Node packages `sharp` and `pngjs`. The reference JavaScript harness is slower but can be run similarly with Node.
