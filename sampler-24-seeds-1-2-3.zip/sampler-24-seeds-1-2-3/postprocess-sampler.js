#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const sharp = require("sharp");

const root = path.resolve(process.argv[2] || "sampler-24-seeds-1-2-3");
const stateDir = path.join(root,"state");
const rawDir = path.join(root,"raw");
const imageDir = path.join(root,"images");
fs.mkdirSync(imageDir,{recursive:true});

const tickValue = name => name.includes("tick-1000000")?1000000:name.match(/tick-(\d+)k/) ? +name.match(/tick-(\d+)k/)[1]*1000 : +name.match(/tick-(\d+)/)[1];
const stateFiles = fs.readdirSync(stateDir).filter(x=>/^seed-\d+_tick-(?:\d+|\d+k)\.json$/.test(x)).sort((a,b)=>{
  const sa=+a.match(/^seed-(\d+)/)[1],sb=+b.match(/^seed-(\d+)/)[1];return sa-sb||tickValue(a)-tickValue(b);
});

const csv = v => {
  const s=v==null?"":String(v);
  return /[",\n]/.test(s)?`"${s.replaceAll('"','""')}"`:s;
};
const metricColumns=["seed","tick","plants","seeds","born","died","recolonised","max_generation","blooms","mean_hue","tissue","petal","core","seed_cell","unique_genotypes","unique_forms"];
const metricRows=[];
const hueColumns=["seed","tick","hue","plant_count","flower_count","living_cell_count","mean_energy","genotype_count","form_count"];
const hueRows=[];

async function main(){
  for(const file of stateFiles){
    const state=JSON.parse(fs.readFileSync(path.join(stateDir,file),"utf8"));
    const tag=file.replace(/\.json$/,'');
    const ppm=path.join(rawDir,`${tag}.ppm`),png=path.join(imageDir,`${tag}.png`);
    const ppmBytes=fs.readFileSync(ppm);let headerEnd=0,newlines=0;
    while(headerEnd<ppmBytes.length&&newlines<3)if(ppmBytes[headerEnd++]===10)newlines++;
    if(newlines!==3)throw new Error(`Invalid PPM header: ${ppm}`);
    await sharp(ppmBytes.subarray(headerEnd),{raw:{width:440,height:735,channels:3}}).png({compressionLevel:9,adaptiveFiltering:false}).toFile(png);
    const forms=new Set(state.plants.map(p=>p.form_code));
    metricRows.push({seed:state.seed,tick:state.tick,...state.totals,unique_genotypes:state.genotypes.length,unique_forms:forms.size});
    const hm=new Map();
    for(const p of state.plants){
      let h=hm.get(p.hue);if(!h)hm.set(p.hue,h={plants:0,flowers:0,cells:0,energy:0,genotypes:new Set(),forms:new Set()});
      h.plants++;h.flowers+=p.flower_count;h.cells+=p.cell_count;h.energy+=p.energy;h.genotypes.add(p.genotype_id);h.forms.add(p.form_code);
    }
    for(const [h,v] of [...hm].sort((a,b)=>a[0]-b[0]))hueRows.push({seed:state.seed,tick:state.tick,hue:h,plant_count:v.plants,flower_count:v.flowers,living_cell_count:v.cells,mean_energy:v.energy/v.plants,genotype_count:v.genotypes.size,form_count:v.forms.size});
  }
  fs.writeFileSync(path.join(root,"metrics.csv"),[metricColumns.join(','),...metricRows.map(r=>metricColumns.map(c=>csv(r[c])).join(','))].join('\n')+'\n');
  fs.writeFileSync(path.join(root,"hues.csv"),[hueColumns.join(','),...hueRows.map(r=>hueColumns.map(c=>csv(r[c])).join(','))].join('\n')+'\n');

  const ticks=[10,100,1000,10000,100000,1000000];
  const tickTags={10:"10",100:"100",1000:"1k",10000:"10k",100000:"100k",1000000:"1000000"};
  const cards=[];
  for(const seed of [1,2,3])for(const tick of ticks){const tag=`seed-${seed}_tick-${tickTags[tick]}`;cards.push(`<figure><a href="images/${tag}.png"><img src="images/${tag}.png" width="440" height="735" loading="lazy" alt="Seed ${seed} at tick ${tick.toLocaleString()}"></a><figcaption>seed ${seed} · tick ${tick.toLocaleString()}</figcaption></figure>`);}
  const html=`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sampler 24 experiment gallery</title><style>html{background:#080a20;color:#c2d09b;font:14px/1.45 ui-monospace,monospace}body{margin:24px}h1{font-size:18px;font-weight:500}p{max-width:75ch;color:#91a377}.gallery{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:24px}figure{margin:0}img{display:block;width:100%;height:auto;image-rendering:pixelated;border:1px solid #1b2145;background:#000}figcaption{margin-top:7px;color:#d4638f}</style></head><body><h1>Sampler 24: seeds 1–3</h1><p>Every image is an exact 440×735-cell canvas at one pixel per cell, after the labeled number of completed simulation ticks. Click any image for the original-resolution PNG.</p><main class="gallery">${cards.join('')}</main></body></html>`;
  fs.writeFileSync(path.join(root,"image-index.html"),html);

  const all=[];function walk(dir){for(const ent of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,ent.name);if(ent.isDirectory()){if(ent.name!=="raw")walk(p);}else if(!p.endsWith('manifest.json'))all.push(p);}}walk(root);
  const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
  const manifest={experiment:"sampler-24",generated_at:new Date().toISOString(),source_sha256:sha(path.join(root,"sampler-24.html")),world:{width:440,height:735,pixel_size:1},seeds:[1,2,3],checkpoints:ticks,files:all.sort().map(p=>({path:path.relative(root,p),bytes:fs.statSync(p).size,sha256:sha(p)}))};
  fs.writeFileSync(path.join(root,"manifest.json"),JSON.stringify(manifest,null,2)+'\n');
}
main().catch(e=>{console.error(e);process.exit(1)});
