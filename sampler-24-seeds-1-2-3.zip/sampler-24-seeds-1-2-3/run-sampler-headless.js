#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const vm = require("vm");
const crypto = require("crypto");
const { PNG } = require("pngjs");

const SOURCE = path.resolve(process.argv[2] || "upload/sampler-24.html");
const OUTPUT = path.resolve(process.argv[3] || "sampler-24-experiment");
const requestedSeeds = (process.argv[4] || "1,2,3").split(",").map(Number);
const checkpoints = (process.argv[5] || "10,100,1000,10000,100000,1000000").split(",").map(Number);
const WORLD_W = 440;
const WORLD_H = 735;
const PIXEL_SIZE = 1;

function mockClassList() {
  return { add() {}, remove() {}, toggle() {}, contains() { return false; } };
}

function makeCanvas() {
  const canvas = {
    width: 0,
    height: 0,
    style: {},
    classList: mockClassList(),
    addEventListener() {},
    getBoundingClientRect() { return { left: 0, top: 0, width: this.width, height: this.height }; },
  };
  const context2d = {
    imageSmoothingEnabled: false,
    createImageData(w, h) { return { width: w, height: h, data: new Uint8ClampedArray(w * h * 4) }; },
    putImageData() {},
    drawImage() {},
  };
  canvas.getContext = () => context2d;
  return canvas;
}

function extractScript(html) {
  const matches = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)];
  if (!matches.length) throw new Error("No inline script found");
  return matches.map(m => m[1]).join("\n");
}

function createSimulation(seed) {
  const mainCanvas = makeCanvas();
  const hud = { textContent: "", classList: mockClassList() };
  const bar = {
    offsetHeight: 50,
    children: [],
    classList: mockClassList(),
    addEventListener() {},
  };
  const document = {
    getElementById(id) {
      if (id === "c") return mainCanvas;
      if (id === "hud") return hud;
      if (id === "bar") return bar;
      throw new Error(`Unexpected element id: ${id}`);
    },
    createElement(tag) {
      if (tag === "canvas") return makeCanvas();
      throw new Error(`Unexpected element: ${tag}`);
    },
  };
  const sandbox = {
    console,
    document,
    location: { search: `?w=${WORLD_W}&h=${WORLD_H}&px=${PIXEL_SIZE}&seed=${seed}` },
    innerWidth: WORLD_W,
    innerHeight: WORLD_H + 50,
    URLSearchParams,
    Uint8Array,
    Uint8ClampedArray,
    Uint16Array,
    Uint32Array,
    Int32Array,
    Float64Array,
    Math,
    Set,
    Map,
    performance: { now: () => 0 },
    requestAnimationFrame() {},
    addEventListener() {},
    clearTimeout() {},
    setTimeout() {},
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);

  const source = extractScript(fs.readFileSync(SOURCE, "utf8"));
  const instrument = `
    // Same tick order and random draws as step(), but compact dead entries once
    // instead of Array.splice() shifting the tail after every death.
    function exactHeadlessStep(){
      tick++;
      tallyBlooms();

      for(let i=plants.length-1;i>=0;i--){
        const p=plants[i];
        p.photosynthesize(); p.grow(); p.sow();
        if(p.cells.length===0 || p.upkeep()){
          p.die(); plants[i]=null;
        }
      }
      let w=0;
      for(let r=0;r<plants.length;r++) if(plants[r]!==null) plants[w++]=plants[r];
      plants.length=w;

      for(let i=seeds.length-1;i>=0;i--) if(!seeds[i].step()) seeds[i]=null;
      w=0;
      for(let r=0;r<seeds.length;r++) if(seeds[r]!==null) seeds[w++]=seeds[r];
      seeds.length=w;

      if(CFG.recolonise && plants.length===0 && seeds.length===0 && tick%400===0){
        colonise(6); recolonised++;
      }
    }
    globalThis.__sampler = {
      runTo(target) { while (tick < target) exactHeadlessStep(); },
      capture() {
        render(); tallyBlooms();
        const plantRecords = plants.map(p => {
          let minX=W, minY=H, maxX=-1, maxY=-1, tissue=0, petals=0, cores=0;
          for (const j of p.cells) {
            const x=j%W, y=(j/W)|0;
            if(x<minX)minX=x; if(x>maxX)maxX=x;
            if(y<minY)minY=y; if(y>maxY)maxY=y;
            if(role[j]===TISSUE)tissue++; else if(role[j]===PETAL)petals++; else if(role[j]===CORE)cores++;
          }
          return {
            id:p.id, generation:p.gen, age:p.age, energy:p.energy,
            open_faces:p.openFaces, done:p.done, pending_jobs:p.queue.length,
            marks:p.marks, sterile_age:p.sterileAge,
            base:[p.baseX,p.baseY], bbox:[minX,minY,maxX,maxY],
            cell_count:p.cells.length, tissue_cells:tissue, petal_cells:petals, core_cells:cores,
            flower_count:p.flowers.length, flower_centers:p.flowers.map(f=>[f.x,f.y]),
            hue:p.genome.hue, form_code:p.formCode, genome:clone(p.genome), cells:p.cells.slice()
          };
        });
        const seedRecords = seeds.map((s,i)=>({
          index:i, generation:s.gen, age:s.age, steps_remaining:s.steps,
          position:[s.x,s.y], occupied_cell:s.i, hue:s.genome.hue,
          form_code:formCode(s.genome), genome:clone(s.genome)
        }));
        const roleCounts={tissue:0,petal:0,core:0,seed_cell:0};
        for(let j=0;j<N;j++){
          if(kind[j]===SEED_CELL){ roleCounts.seed_cell++; continue; }
          if(kind[j]!==LIVE) continue;
          if(role[j]===TISSUE)roleCounts.tissue++;
          else if(role[j]===PETAL)roleCounts.petal++;
          else if(role[j]===CORE)roleCounts.core++;
        }
        return {
          rgba:Array.from(img.data),
          state:{
            schema:"sampler-24-headless-state-v1", seed:worldSeed, rng_state:rngState>>>0,
            tick, width:W, height:H, pixel_size:CFG.px,
            totals:{plants:plants.length,seeds:seeds.length,born,died,recolonised,
              max_generation:generation,blooms:bloomCount,mean_hue:meanDefined?meanHue:null,
              ...roleCounts},
            constants:{UPKEEP,SENESCE,AGE_COST,MARK_COST,SEED_ENERGY,SEED_COST,STARVE_DEBT,
              PHOTO,BLK,SEED_WALK,SEED_LIFE,GERM_CLEAR,MUT_P,GRACE,PATIENCE,HUE_MUT,
              HUE_STEP,NOVELTY,MUT_P2,MAX_NODES},
            plants:plantRecords,seeds:seedRecords
          }
        };
      }
    };
  `;
  vm.runInContext(`${source}\n${instrument}`, sandbox, { filename: SOURCE });
  return sandbox.__sampler;
}

function safeTick(t) {
  if (t >= 1000000) return "1000000";
  if (t >= 1000) return `${t / 1000}k`;
  return String(t);
}

function csvEscape(v) {
  if (v == null) return "";
  const s = Array.isArray(v) ? v.join(";") : String(v);
  return /[",\n]/.test(s) ? `"${s.replaceAll('"','""')}"` : s;
}

function summarizeForms(plants) {
  const groups = new Map();
  for (const p of plants) {
    const key = `${p.form_code}\u0000${p.hue}`;
    let g = groups.get(key);
    if (!g) {
      g = { form_code:p.form_code, hue:p.hue, count:0, cells:0, flowers:0, energy:0,
            min_cells:Infinity, max_cells:-Infinity, generations:new Set() };
      groups.set(key,g);
    }
    g.count++; g.cells+=p.cell_count; g.flowers+=p.flower_count; g.energy+=p.energy;
    g.min_cells=Math.min(g.min_cells,p.cell_count); g.max_cells=Math.max(g.max_cells,p.cell_count);
    g.generations.add(p.generation);
  }
  return [...groups.values()].map(g=>({
    form_code:g.form_code,hue:g.hue,count:g.count,
    mean_cells:g.cells/g.count,min_cells:g.min_cells,max_cells:g.max_cells,
    mean_flowers:g.flowers/g.count,mean_energy:g.energy/g.count,
    min_generation:Math.min(...g.generations),max_generation:Math.max(...g.generations)
  })).sort((a,b)=>b.count-a.count||b.mean_cells-a.mean_cells);
}

function writeCsv(file, rows, columns) {
  const lines = [columns.join(",")];
  for (const row of rows) lines.push(columns.map(c=>csvEscape(row[c])).join(","));
  fs.writeFileSync(file, lines.join("\n")+"\n");
}

function sha256(file) {
  return crypto.createHash("sha256").update(fs.readFileSync(file)).digest("hex");
}

fs.mkdirSync(OUTPUT, { recursive: true });
fs.mkdirSync(path.join(OUTPUT,"images"), { recursive: true });
fs.mkdirSync(path.join(OUTPUT,"state"), { recursive: true });
fs.copyFileSync(SOURCE, path.join(OUTPUT,"sampler-24.html"));
fs.copyFileSync(__filename, path.join(OUTPUT,"run-sampler-headless.js"));

const manifest = {
  experiment:"sampler-24", generated_at:new Date().toISOString(),
  source_file:"sampler-24.html", source_sha256:sha256(SOURCE),
  runner_file:"run-sampler-headless.js", runner_sha256:sha256(__filename),
  world:{width:WORLD_W,height:WORLD_H,pixel_size:PIXEL_SIZE},
  seeds:requestedSeeds,checkpoints,artifacts:[]
};

for (const seed of requestedSeeds) {
  const sim = createSimulation(seed);
  for (const checkpoint of checkpoints) {
    const started = Date.now();
    sim.runTo(checkpoint);
    const captured = sim.capture();
    const tag=`seed-${seed}_tick-${safeTick(checkpoint)}`;
    const pngPath=path.join(OUTPUT,"images",`${tag}.png`);
    const statePath=path.join(OUTPUT,"state",`${tag}.json`);
    const plantsPath=path.join(OUTPUT,"state",`${tag}_plants.csv`);
    const formsPath=path.join(OUTPUT,"state",`${tag}_forms.csv`);
    const png = new PNG({width:WORLD_W,height:WORLD_H});
    png.data = Buffer.from(captured.rgba);
    fs.writeFileSync(pngPath, PNG.sync.write(png,{colorType:6,inputColorType:6,inputHasAlpha:true}));
    fs.writeFileSync(statePath, JSON.stringify(captured.state));
    writeCsv(plantsPath,captured.state.plants,[
      "id","generation","age","energy","open_faces","done","pending_jobs","marks","sterile_age",
      "base","bbox","cell_count","tissue_cells","petal_cells","core_cells","flower_count","hue","form_code"
    ]);
    writeCsv(formsPath,summarizeForms(captured.state.plants),[
      "form_code","hue","count","mean_cells","min_cells","max_cells","mean_flowers","mean_energy","min_generation","max_generation"
    ]);
    for(const file of [pngPath,statePath,plantsPath,formsPath]){
      manifest.artifacts.push({path:path.relative(OUTPUT,file),bytes:fs.statSync(file).size,sha256:sha256(file)});
    }
    console.log(JSON.stringify({seed,tick:checkpoint,elapsed_ms:Date.now()-started,
      plants:captured.state.totals.plants,seeds:captured.state.totals.seeds,
      cells:captured.state.totals.tissue+captured.state.totals.petal+captured.state.totals.core,
      generation:captured.state.totals.max_generation}));
  }
}

fs.writeFileSync(path.join(OUTPUT,"manifest.json"),JSON.stringify(manifest,null,2)+"\n");
console.log(`DONE ${OUTPUT}`);
