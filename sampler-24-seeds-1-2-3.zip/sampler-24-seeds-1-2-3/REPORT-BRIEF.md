# Brief for the visual analysis report

Create a clear, serious, static HTML report from this experiment package. Emphasize visual evidence: use many original screenshots and purposeful crops, with annotations or captions that point to the exact structures being discussed. Avoid decorative infographics, dashboard polish, and superficial summary language. Images plus rigorous prose are enough.

## Core questions

1. At each tick stage, what body plans are most common, both within each run and across all three runs? Which strategies is natural selection rewarding, and what mechanism plausibly rewards them?
2. Identify the longest, shortest, most spatially expansive, most cell-dense, most flower-rich, and most unusual mature forms. Distinguish genotype size from realized body size when crowding prevents full development.
3. What happens to flower color through time? Analyze circular hue correctly: 253 and 3 are close, not far apart. Examine global patterns and multiple local scales, especially scales near the model's 16-cell blocks and nine-block novelty neighborhood.
4. Evaluate the project's three goals: legibility; emergent evolution/natural selection and possible co-evolution from a common ancestor; and simple biophilic or millefleur-like forms. Give separate, candid assessments with visual evidence.
5. Look for rare genetic or morphological innovations. Explain why each is genuinely unusual relative to the observed genotype distribution, not merely visually conspicuous.
6. Look for spatially persistent ecotypes, lineage-like clusters, ecological differentiation, reciprocal adaptation, or other evidence relevant to speciation and co-evolution. Apply the cautions in `README.md`; do not inflate clonal clusters into biological species.
7. Explain what the system is doing in scholarly terms and assess how novel, scientifically useful, or study-worthy it realistically is.
8. Offer 3–7 viable redesign directions most likely to improve the three goals and generate open-ended, unexpected behavior. Light/shading, soil/litter, and rain previously added complexity without clearly advancing the goals, so do not recommend them by reflex; only revisit them with a more principled mechanism.

## Analytical expectations

- Start from the images, then use `metrics.csv`, `hues.csv`, per-snapshot plant/form CSVs, and full JSON to test visual impressions.
- Separate direct observation, quantitative result, mechanistic inference, and speculation.
- Compare seeds 1–3. A pattern seen in one seed at one checkpoint is an anecdote; a repeated trajectory is stronger evidence.
- Track survivorship bias. Snapshot abundance rewards forms that live long as well as forms that reproduce rapidly.
- Parse `form_code` or the genome trees when discussing grammar complexity. Use occupied cells and bounding boxes when discussing realized morphology.
- When choosing visual examples, report seed, tick, plant ID, hue, form code, and bounding box so another analyst can reproduce the crop.
- Use exact circular statistics for hue: circular mean/resultant length, dispersion, and hue-gap distributions. Examine spatial autocorrelation or local entropy at several window sizes.
- Look for convergence: different genotypes that yield similar realized body plans, and similar genotypes that develop differently because of crowding.
- Test whether greater exposed perimeter, branching, bloom number, compactness, height/verticality, or lifespan is associated with abundance and energy. Remember that selection acts through completed reproduction, not aesthetic appearance.

## Scholarly research standard

Do fresh research and cite primary sources wherever possible. Situate the system against, at minimum:

- digital evolution and artificial-life platforms such as Tierra and Avida;
- L-systems, graph grammars, evolutionary developmental systems, and genotype-phenotype mappings;
- open-ended evolution and its major obstacles, including unbounded novelty, ecological interaction, and major transitions;
- novelty search, quality-diversity, and minimal-criterion approaches, while distinguishing them from this model's explicit local hue novelty advantage;
- spatial eco-evolutionary dynamics, negative frequency-dependent selection, niche construction, and character displacement;
- Dave Ackley's work on robust-first computing and indefinite scalability;
- relevant ideas from Terence Tao only where there is a real methodological connection, such as choosing productive invariants, multiscale structure, local-to-global reasoning, or computational experiment design. Do not use his name as inspirational decoration.

Give a skeptical novelty assessment. Distinguish:

- novelty of the specific combination and presentation;
- novelty of the underlying mechanisms;
- scientific value as a model organism or experimental platform;
- artistic/generative value;
- what evidence would be needed for a publishable claim.

## Redesign criteria

For each proposed direction, specify:

- the smallest rule change;
- the selection pressure it creates without an arbitrary global fitness score;
- the expected visible behavior;
- why it could produce reciprocal ecological dependence or deeper open-endedness;
- the major failure mode or confound;
- a falsifiable short experiment, including which metrics and checkpoints would decide whether to keep it.

Favor orthogonal mechanisms that create new adaptive dimensions rather than additional resource bookkeeping. Examples worth evaluating, not automatically endorsing, include heritable developmental timing, tissue-function tradeoffs, local signaling, partner-specific exchange, antagonistic attachment, limited recombination, heritable seed dispersal, or environmental modification that persists and affects descendants.
